// Clean Student Dashboard - FIXED THUMBNAIL DISPLAY
class DashboardManager {
    constructor() {
        this.currentUser = null;
        this.initialize();
    }

    initialize() {
        this.checkAuthentication();
        this.loadUserData();
        this.setupEventListeners();
        this.displayCourses();
        this.updateStats();
    }

    checkAuthentication() {
        const currentUserEmail = localStorage.getItem('currentUser');
        if (!currentUserEmail) {
            window.location.href = 'index.html';
            return;
        }
        
        const userProfiles = JSON.parse(localStorage.getItem('userProfiles') || '{}');
        this.currentUser = userProfiles[currentUserEmail];
        
        if (!this.currentUser) {
            window.location.href = 'index.html';
            return;
        }
    }

    loadUserData() {
        document.getElementById('userName').textContent = 
            `${this.currentUser.firstName} ${this.currentUser.lastName}`;
        document.getElementById('welcomeUserName').textContent = this.currentUser.firstName;
        
        const initials = this.currentUser.firstName.charAt(0) + this.currentUser.lastName.charAt(0);
        document.getElementById('userAvatar').textContent = initials.toUpperCase();
    }

    setupEventListeners() {
        document.querySelectorAll('.sidebar-menu li').forEach(item => {
            if (item.onclick) return;
            
            item.addEventListener('click', () => {
                const page = item.getAttribute('data-page');
                if (page) {
                    this.showPage(page);
                }
            });
        });

        const userMenu = document.querySelector('.user-menu');
        const dropdown = document.getElementById('userDropdown');
        
        if (userMenu && dropdown) {
            userMenu.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('hidden');
            });

            document.addEventListener('click', () => {
                dropdown.classList.add('hidden');
            });
        }

        const searchInput = document.getElementById('globalSearch');
        if (searchInput) {
            searchInput.addEventListener('input', Utils.debounce(() => {
                this.handleSearch(searchInput.value);
            }, 300));

            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.handleSearch(searchInput.value);
                }
            });
        }
    }

    showPage(pageId) {
        document.querySelectorAll('.page-content').forEach(page => {
            page.classList.remove('active');
            page.classList.add('hidden');
        });

        const targetPage = document.getElementById(`${pageId}-page`);
        if (targetPage) {
            targetPage.classList.remove('hidden');
            targetPage.classList.add('active');
        }

        document.querySelectorAll('.sidebar-menu li').forEach(item => {
            item.classList.remove('active');
        });
        
        const activeItem = document.querySelector(`[data-page="${pageId}"]`);
        if (activeItem) {
            activeItem.classList.add('active');
        }

        this.loadPageContent(pageId);
    }

    loadPageContent(pageId) {
        switch (pageId) {
            case 'dashboard':
                this.displayCourses();
                this.updateStats();
                break;
            case 'my-courses':
                this.loadMyCourses();
                break;
        }
    }

    displayCourses() {
        const enrolledCourses = window.courseManager.getUserCourses(this.currentUser.email);
        
        this.displayContinueLearning(enrolledCourses);
        
        const allCourses = window.courseManager.getAllCourses();
        const recommendedCourses = allCourses.filter(course => 
            !window.courseManager.isEnrolled(this.currentUser.email, course.id) &&
            course.creatorEmail !== this.currentUser.email
        );
        this.displayRecommendedCourses(recommendedCourses);
        
        this.displayEnrolledSidebar(enrolledCourses);
    }

    // FIXED: Proper thumbnail rendering
    renderCourseThumbnail(course) {
        // Check if thumbnail is a base64 image or emoji
        if (course.thumbnail && course.thumbnail.startsWith('data:image')) {
            // It's a base64 image - render as <img>
            return `<img src="${course.thumbnail}" alt="${course.title}" style="width: 100%; height: 100%; object-fit: cover;">`;
        } else {
            // It's an emoji or text - render as text
            return course.thumbnail || '📚';
        }
    }

    displayContinueLearning(courses) {
        const container = document.getElementById('continueLearningGrid');
        
        if (courses.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-play-circle"></i>
                    <h3>No courses enrolled</h3>
                    <p>Explore and enroll in courses to start learning</p>
                </div>
            `;
            return;
        }

        container.innerHTML = courses.map(course => {
            const progress = window.courseManager.getCourseProgress(this.currentUser.email, course.id);
            return `
                <div class="course-card" onclick="dashboard.openCourse(${course.id})">
                    <div class="course-image">
                        ${this.renderCourseThumbnail(course)}
                        <div class="course-progress">
                            <div class="course-progress-bar" style="width: ${progress}%"></div>
                        </div>
                    </div>
                    <div class="course-content">
                        <div class="course-title">${course.title}</div>
                        <div class="course-instructor">
                            <i class="fas fa-user"></i>
                            ${course.creatorName}
                        </div>
                        <div class="course-description">${course.description || 'No description'}</div>
                        <button class="continue-btn" onclick="event.stopPropagation(); dashboard.openCourse(${course.id})">
                            Continue Learning
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }

    displayRecommendedCourses(courses) {
        const container = document.getElementById('recommendedCoursesGrid');
        
        if (courses.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-search"></i>
                    <h3>No courses available</h3>
                    <p>Check back later for new courses</p>
                </div>
            `;
            return;
        }

        container.innerHTML = courses.map(course => `
            <div class="course-card" onclick="dashboard.showCourseDetails(${course.id})">
                <div class="course-image">
                    ${this.renderCourseThumbnail(course)}
                    <div class="course-badge">New</div>
                </div>
                <div class="course-content">
                    <div class="course-title">${course.title}</div>
                    <div class="course-instructor">
                        <i class="fas fa-user"></i>
                        ${course.creatorName}
                    </div>
                    <div class="course-description">${course.description || 'No description'}</div>
                    <button class="enroll-btn" onclick="event.stopPropagation(); dashboard.enrollInCourse(${course.id})">
                        Enroll Now
                    </button>
                </div>
            </div>
        `).join('');
    }

    displayEnrolledSidebar(courses) {
        const container = document.getElementById('enrolledCoursesSidebar');
        
        if (courses.length === 0) {
            container.innerHTML = `
                <li style="color: var(--text-secondary); font-style: italic; padding: 1rem;">
                    No courses enrolled
                </li>
            `;
            return;
        }

        container.innerHTML = courses.map(course => {
            const progress = window.courseManager.getCourseProgress(this.currentUser.email, course.id);
            return `
                <li onclick="dashboard.openCourse(${course.id})">
                    <i class="fas fa-book"></i>
                    <span>${course.title}</span>
                    <div class="progress-indicator" style="background: var(--border-color);">
                        <div class="progress-fill" style="width: ${progress}%; background: var(--primary-color);"></div>
                    </div>
                </li>
            `;
        }).join('');
    }

    loadMyCourses() {
        const container = document.getElementById('myCoursesContainer');
        const enrolledCourses = window.courseManager.getUserCourses(this.currentUser.email);
        
        if (enrolledCourses.length === 0) {
            container.innerHTML = `
                <div class="empty-state large">
                    <i class="fas fa-book-open"></i>
                    <h2>No Courses Enrolled</h2>
                    <p>Start by exploring and enrolling in courses that interest you</p>
                </div>
            `;
            return;
        }

        container.innerHTML = enrolledCourses.map(course => {
            const progress = window.courseManager.getCourseProgress(this.currentUser.email, course.id);
            return `
                <div class="my-course-card">
                    <div class="course-header">
                        <div class="course-info">
                            <h3>${course.title}</h3>
                            <p>by ${course.creatorName}</p>
                        </div>
                        <div class="course-progress-display">
                            <span class="progress-percentage">${Math.round(progress)}%</span>
                            <div class="progress-bar">
                                <div class="progress-fill" style="width: ${progress}%"></div>
                            </div>
                        </div>
                    </div>
                    <div class="course-actions">
                        <button class="btn-outline" onclick="dashboard.openCourse(${course.id})">
                            <i class="fas fa-play"></i>
                            Continue
                        </button>
                        <button class="btn-outline" onclick="dashboard.unenrollFromCourse(${course.id})">
                            <i class="fas fa-times"></i>
                            Unenroll
                        </button>
                    </div>
                </div>
            `;
        }).join('');
    }

    updateStats() {
        const enrolledCourses = window.courseManager.getUserCourses(this.currentUser.email);
        
        document.getElementById('activeCourses').textContent = enrolledCourses.length;
        document.getElementById('completed').textContent = '0';
        document.getElementById('studyTime').textContent = '0h';
    }

    showCourseDetails(courseId) {
        const course = window.courseManager.getCourse(courseId);
        if (!course) return;

        const isEnrolled = window.courseManager.isEnrolled(this.currentUser.email, courseId);
        
        let reviewsHTML = '';
        if (typeof reviewManager !== 'undefined') {
            reviewsHTML = reviewManager.generateReviewsHTML(courseId, isEnrolled);
        }
        
        document.getElementById('courseModalTitle').textContent = course.title;
        document.getElementById('courseModalContent').innerHTML = `
            <div class="course-modal-content">
                <div class="modal-course-header">
                    <div class="modal-course-image">
                        ${this.renderCourseThumbnail(course)}
                    </div>
                    <div class="modal-course-info">
                        <h3>${course.title}</h3>
                        <p class="course-instructor">by ${course.creatorName}</p>
                        <div class="course-meta">
                            <span><i class="fas fa-video"></i> ${course.videos.length} videos</span>
                            <span><i class="fas fa-calendar"></i> ${new Date(course.createdDate).toLocaleDateString()}</span>
                        </div>
                        ${isEnrolled ? `
                            <div class="enrollment-status">
                                <i class="fas fa-check-circle"></i>
                                Enrolled
                            </div>
                        ` : ''}
                    </div>
                </div>
                
                <div class="modal-course-description">
                    <h4>About this course</h4>
                    <p>${course.description || 'No description available'}</p>
                </div>

                <div class="modal-course-actions">
                    ${isEnrolled ? `
                        <button class="btn-primary" onclick="dashboard.openCourse(${course.id}); closeCourseModal()">
                            <i class="fas fa-play"></i>
                            Start Learning
                        </button>
                        <button class="btn-outline" onclick="dashboard.unenrollFromCourse(${course.id}); closeCourseModal()">
                            <i class="fas fa-times"></i>
                            Unenroll
                        </button>
                    ` : `
                        <button class="btn-primary" onclick="dashboard.enrollInCourse(${course.id}); closeCourseModal()">
                            <i class="fas fa-plus"></i>
                            Enroll Now
                        </button>
                    `}
                </div>

                ${reviewsHTML}
            </div>
        `;

        document.getElementById('courseModal').classList.remove('hidden');
    }

    enrollInCourse(courseId) {
        const success = window.courseManager.enrollUser(this.currentUser.email, courseId);
        if (success) {
            showNotification('Successfully enrolled in course!', 'success');
            this.displayCourses();
            this.updateStats();
        }
    }

    unenrollFromCourse(courseId) {
        if (confirm('Are you sure you want to unenroll from this course?')) {
            window.courseManager.unenrollUser(this.currentUser.email, courseId);
            showNotification('Unenrolled from course', 'info');
            this.displayCourses();
            this.updateStats();
        }
    }

    openCourse(courseId) {
        const course = window.courseManager.getCourse(courseId);
        if (!course || course.videos.length === 0) {
            showNotification('This course has no videos yet', 'error');
            return;
        }
        
        window.location.href = `video-player.html?courseId=${courseId}`;
    }

    handleSearch(query) {
        if (!query.trim()) {
            if (typeof searchManager !== 'undefined') {
                searchManager.hideSearchResults();
            }
            return;
        }

        if (typeof searchManager !== 'undefined') {
            searchManager.performSearch(query);
        }
    }
}

function closeCourseModal() {
    document.getElementById('courseModal').classList.add('hidden');
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('currentUser');
        window.location.href = 'index.html';
    }
}

let dashboard;
document.addEventListener('DOMContentLoaded', function() {
    dashboard = new DashboardManager();
});

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;

    if (!document.querySelector('.notification-styles')) {
        const styles = document.createElement('style');
        styles.className = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                z-index: 3000;
                display: flex;
                align-items: center;
                gap: 1rem;
                max-width: 400px;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
            }
            .notification-success { background: rgba(16, 185, 129, 0.9); }
            .notification-error { background: rgba(239, 68, 68, 0.9); }
            .notification-info { background: rgba(59, 130, 246, 0.9); }
            .notification button {
                background: none;
                border: none;
                color: white;
                font-size: 1.2rem;
                cursor: pointer;
            }
        `;
        document.head.appendChild(styles);
    }

    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}