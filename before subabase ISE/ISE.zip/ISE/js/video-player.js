class VideoPlayer {
    constructor() {
        this.currentUser = null;
        this.courseId = null;
        this.course = null;
        this.currentVideoIndex = 0;
        this.selectedRating = 0;
        this.comments = {};
        this.reviews = {};
        this.videoDB = null;
        this.videoBlobUrls = {};
        this.autoSaveInterval = null;
        this.lastSaveTime = 0;
        this.watchedSegments = [];
        this.initialize();
    }

    async initialize() {
        await this.initializeDB();
        this.checkAuthentication();
        this.loadFromStorage();
        this.getCourseFromURL();
        this.setupEventListeners();
        await this.loadCourseContent();
        this.loadCommentsAndReviews();
        this.startAutoSave();
    }

    async initializeDB() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open('SkillShareVideoDB', 1);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.videoDB = request.result;
                console.log('VideoPlayer: IndexedDB connected');
                resolve(this.videoDB);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains('videos')) {
                    db.createObjectStore('videos', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('thumbnails')) {
                    db.createObjectStore('thumbnails', { keyPath: 'id' });
                }
            };
        });
    }

    async getVideoBlob(videoId) {
        const transaction = this.videoDB.transaction(['videos'], 'readonly');
        const store = transaction.objectStore('videos');
        
        return new Promise((resolve, reject) => {
            const request = store.get(videoId);
            request.onsuccess = () => {
                if (request.result && request.result.blob) {
                    resolve(request.result.blob);
                } else {
                    resolve(null);
                }
            };
            request.onerror = () => reject(request.error);
        });
    }

    checkAuthentication() {
        const currentUserEmail = localStorage.getItem('currentUser');
        if (!currentUserEmail) {
            window.location.href = 'index.html';
            return;
        }
        
        const userProfiles = JSON.parse(localStorage.getItem('userProfiles') || '{}');
        this.currentUser = userProfiles[currentUserEmail];
        
        if (!this.currentUser) {
            window.location.href = 'index.html';
            return;
        }

        const userName = document.getElementById('userName');
        const userAvatar = document.getElementById('userAvatar');
        const commentAvatar = document.getElementById('commentAvatar');
        
        if (userName) userName.textContent = `${this.currentUser.firstName} ${this.currentUser.lastName}`;
        const initials = this.currentUser.firstName.charAt(0) + this.currentUser.lastName.charAt(0);
        if (userAvatar) userAvatar.textContent = initials.toUpperCase();
        if (commentAvatar) commentAvatar.textContent = initials.toUpperCase();
    }

    loadFromStorage() {
        this.comments = JSON.parse(localStorage.getItem('courseComments')) || {};
        this.reviews = JSON.parse(localStorage.getItem('courseReviews')) || {};
    }

    saveToStorage() {
        localStorage.setItem('courseComments', JSON.stringify(this.comments));
        localStorage.setItem('courseReviews', JSON.stringify(this.reviews));
    }

    getCourseFromURL() {
        const urlParams = new URLSearchParams(window.location.search);
        this.courseId = urlParams.get('courseId');
        
        if (!this.courseId) {
            showNotification('No course specified', 'error');
            setTimeout(() => history.back(), 2000);
            return;
        }

        this.course = window.courseManager.getCourse(this.courseId);
        
        if (!this.course) {
            showNotification('Course not found', 'error');
            setTimeout(() => history.back(), 2000);
            return;
        }

        if (!window.courseManager.isEnrolled(this.currentUser.email, this.courseId)) {
            showNotification('You must be enrolled in this course', 'error');
            setTimeout(() => history.back(), 2000);
            return;
        }
    }

    startAutoSave() {
        if (this.autoSaveInterval) {
            clearInterval(this.autoSaveInterval);
        }
        
        this.autoSaveInterval = setInterval(() => {
            this.performAutoSave();
        }, 10000);
        
        console.log('Auto-save started (every 10 seconds)');
    }

    performAutoSave() {
        const videoPlayer = document.getElementById('videoPlayer');
        const video = this.course?.videos[this.currentVideoIndex];
        
        if (video && videoPlayer && videoPlayer.currentTime > 0 && !videoPlayer.paused) {
            window.courseManager.saveVideoProgress(
                this.currentUser.email,
                this.courseId,
                video.id,
                videoPlayer.currentTime,
                videoPlayer.duration
            );
            
            this.showAutoSaveIndicator();
            this.updateProgressDisplay();
            console.log(`Auto-saved at ${Math.floor(videoPlayer.currentTime)}s`);
        }
    }

    showAutoSaveIndicator() {
        const indicator = document.getElementById('autoSaveIndicator');
        if (indicator) {
            indicator.classList.add('saving');
            setTimeout(() => {
                indicator.classList.remove('saving');
            }, 1500);
        }
    }

    updateProgressDisplay() {
        const videoPlayer = document.getElementById('videoPlayer');
        const watchProgress = document.getElementById('watchProgress');
        
        if (videoPlayer && watchProgress && videoPlayer.duration > 0) {
            const percentage = Math.round((videoPlayer.currentTime / videoPlayer.duration) * 100);
            watchProgress.textContent = `Progress: ${percentage}%`;
        }
        
        this.displayVideosList();
    }

    setupEventListeners() {
        const video = document.getElementById('videoPlayer');
        
        if (video) {
            video.addEventListener('timeupdate', () => {
                this.onTimeUpdate();
            });

            video.addEventListener('ended', () => {
                this.onVideoEnd();
            });
            
            video.addEventListener('pause', () => {
                this.saveProgressNow();
            });
            
            video.addEventListener('seeked', () => {
                this.saveProgressNow();
            });
        }

        document.querySelectorAll('.star-btn').forEach(star => {
            star.addEventListener('click', (e) => {
                this.selectedRating = parseInt(e.target.dataset.rating);
                this.updateStarRating();
            });
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const wrapper = document.getElementById('videoPlayerWrapper');
                if (wrapper && wrapper.classList.contains('fullscreen')) {
                    this.toggleFullscreen();
                }
            }
        });

        document.addEventListener('fullscreenchange', () => {
            if (!document.fullscreenElement) {
                this.exitFullscreenMode();
            }
        });

        document.addEventListener('webkitfullscreenchange', () => {
            if (!document.webkitFullscreenElement) {
                this.exitFullscreenMode();
            }
        });

        window.addEventListener('beforeunload', () => {
            this.saveProgressNow();
            if (this.autoSaveInterval) {
                clearInterval(this.autoSaveInterval);
            }
            Object.values(this.videoBlobUrls).forEach(url => URL.revokeObjectURL(url));
        });
    }

    exitFullscreenMode() {
        const wrapper = document.getElementById('videoPlayerWrapper');
        const btn = document.getElementById('fullscreenBtn');
        if (wrapper) wrapper.classList.remove('fullscreen');
        if (btn) btn.innerHTML = '<span class="fas fa-expand"></span><span>Fullscreen</span>';
    }

    onTimeUpdate() {
        const videoPlayer = document.getElementById('videoPlayer');
        const watchProgress = document.getElementById('watchProgress');
        
        if (videoPlayer && watchProgress && videoPlayer.duration > 0) {
            const percentage = Math.round((videoPlayer.currentTime / videoPlayer.duration) * 100);
            watchProgress.textContent = `Progress: ${percentage}%`;
        }
        
        this.updateRatingEligibility();
    }

    updateRatingEligibility() {
        const overallProgress = window.courseManager.getCourseProgress(
            this.currentUser.email,
            this.courseId
        );
        
        const eligibilityEl = document.getElementById('ratingEligibility');
        const submitBtn = document.getElementById('submitReviewBtn');
        
        if (eligibilityEl && submitBtn) {
            if (overallProgress >= 50) {
                eligibilityEl.textContent = 'You can now leave a rating!';
                eligibilityEl.style.color = '#10b981';
                submitBtn.disabled = false;
            } else {
                eligibilityEl.textContent = `Watch at least 50% of the course to leave a rating (${Math.round(overallProgress)}% watched)`;
                eligibilityEl.style.color = '#f59e0b';
                submitBtn.disabled = true;
            }
        }
    }

    saveProgressNow() {
        const videoPlayer = document.getElementById('videoPlayer');
        const video = this.course?.videos[this.currentVideoIndex];
        
        if (video && videoPlayer && videoPlayer.currentTime > 0) {
            window.courseManager.saveVideoProgress(
                this.currentUser.email,
                this.courseId,
                video.id,
                videoPlayer.currentTime,
                videoPlayer.duration
            );
            console.log('Progress saved immediately');
        }
    }

    toggleFullscreen() {
        const wrapper = document.getElementById('videoPlayerWrapper');
        const btn = document.getElementById('fullscreenBtn');
        
        if (!wrapper) return;
        
        if (!wrapper.classList.contains('fullscreen')) {
            wrapper.classList.add('fullscreen');
            if (btn) btn.innerHTML = '<span class="fas fa-compress"></span><span>Exit Fullscreen</span>';
            
            if (wrapper.requestFullscreen) {
                wrapper.requestFullscreen();
            } else if (wrapper.webkitRequestFullscreen) {
                wrapper.webkitRequestFullscreen();
            }
        } else {
            wrapper.classList.remove('fullscreen');
            if (btn) btn.innerHTML = '<span class="fas fa-expand"></span><span>Fullscreen</span>';
            
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            }
        }
    }

    async loadCourseContent() {
        if (!this.course || this.course.videos.length === 0) {
            showNotification('This course has no videos', 'error');
            return;
        }

        const courseTitle = document.getElementById('courseTitle');
        if (courseTitle) courseTitle.textContent = this.course.title;
        
        this.displayVideosList();
        await this.loadVideo(0);
    }

    displayVideosList() {
        const container = document.getElementById('courseVideosList');
        if (!container) return;
        
        container.innerHTML = this.course.videos.map((video, index) => {
            const progress = window.courseManager.getVideoProgress(
                this.currentUser.email, 
                this.courseId, 
                video.id
            );
            const percentage = progress ? progress.percentage : 0;
            const isComplete = percentage >= 90;
            
            return `
                <div class="video-item ${index === this.currentVideoIndex ? 'active' : ''} ${isComplete ? 'completed' : ''}" 
                     onclick="videoPlayer.loadVideo(${index})">
                    <div class="video-item-number">
                        ${isComplete ? '<span class="fas fa-check"></span>' : index + 1}
                    </div>
                    <div class="video-item-info">
                        <div class="video-item-title">${video.name}</div>
                        <div class="video-item-progress">
                            <div class="progress-bar-small">
                                <div class="progress-fill-small" style="width: ${percentage}%"></div>
                            </div>
                            <span>${Math.round(percentage)}%</span>
                        </div>
                    </div>
                    ${index === this.currentVideoIndex ? '<span class="fas fa-play-circle playing-icon"></span>' : ''}
                </div>
            `;
        }).join('');

        const overallProgress = window.courseManager.getCourseProgress(
            this.currentUser.email, 
            this.courseId
        );
        const courseProgress = document.getElementById('courseProgress');
        if (courseProgress) courseProgress.textContent = Math.round(overallProgress) + '%';
    }

    async loadVideo(index) {
        if (index < 0 || index >= this.course.videos.length) return;
        
        this.saveProgressNow();
        
        this.currentVideoIndex = index;
        const video = this.course.videos[index];
        
        const videoTitle = document.getElementById('videoTitle');
        const videoNumber = document.getElementById('videoNumber');
        
        if (videoTitle) videoTitle.textContent = video.name;
        if (videoNumber) videoNumber.textContent = `Video ${index + 1} of ${this.course.videos.length}`;
        
        const videoPlayer = document.getElementById('videoPlayer');
        const videoSource = document.getElementById('videoSource');
        
        showNotification('Loading video...', 'info');
        
        try {
            const videoBlob = await this.getVideoBlob(video.id);
            
            if (videoBlob) {
                if (this.videoBlobUrls[video.id]) {
                    URL.revokeObjectURL(this.videoBlobUrls[video.id]);
                }
                
                const blobUrl = URL.createObjectURL(videoBlob);
                this.videoBlobUrls[video.id] = blobUrl;
                
                videoSource.src = blobUrl;
                videoPlayer.load();
                
                const progress = window.courseManager.getVideoProgress(
                    this.currentUser.email,
                    this.courseId,
                    video.id
                );
                
                if (progress && progress.currentTime > 0) {
                    videoPlayer.currentTime = progress.currentTime;
                }
                
                videoPlayer.play();
                console.log('Video loaded successfully');
            } else {
                showNotification('Video file not found. It may have been deleted.', 'error');
                console.error('Video blob not found for ID:', video.id);
            }
        } catch (error) {
            console.error('Error loading video:', error);
            showNotification('Failed to load video', 'error');
        }
        
        this.displayVideosList();
        this.loadCommentsAndReviews();
        this.updateRatingEligibility();
    }

    onVideoEnd() {
        this.saveProgressNow();
        
        if (this.currentVideoIndex < this.course.videos.length - 1) {
            showNotification('Next video starting in 3 seconds...', 'info');
            setTimeout(() => {
                this.loadVideo(this.currentVideoIndex + 1);
            }, 3000);
        } else {
            const overallProgress = window.courseManager.getCourseProgress(
                this.currentUser.email, 
                this.courseId
            );
            
            if (overallProgress >= 90) {
                showNotification('Congratulations! You have completed this course!', 'success');
                this.showCompletionCertificate();
            } else {
                showNotification('Course completed! Watch more to reach 90% for your certificate.', 'success');
            }
        }
    }

    showCompletionCertificate() {
        const modal = document.createElement('div');
        modal.className = 'certificate-modal';
        modal.innerHTML = `
            <div class="certificate-content">
                <div class="certificate-close" onclick="this.parentElement.parentElement.remove()">
                    <span class="fas fa-times"></span>
                </div>
                <div class="certificate">
                    <div class="certificate-header">
                        <span class="fas fa-award certificate-icon"></span>
                        <h2>Certificate of Completion</h2>
                    </div>
                    <div class="certificate-body">
                        <p>This is to certify that</p>
                        <h3 class="certificate-name">${this.currentUser.firstName} ${this.currentUser.lastName}</h3>
                        <p>has successfully completed the course</p>
                        <h4 class="certificate-course">${this.course.title}</h4>
                        <p>on ${new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                    </div>
                    <div class="certificate-footer">
                        <div class="certificate-logo">
                            <span class="fas fa-graduation-cap"></span>
                            <span>SkillShare</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(modal);
    }

    loadCommentsAndReviews() {
        this.loadComments();
        this.loadReviews();
    }

    loadComments() {
        const key = `${this.courseId}`;
        const courseComments = this.comments[key] || [];
        
        const commentCount = document.getElementById('commentCount');
        if (commentCount) commentCount.textContent = courseComments.length;
        
        const container = document.getElementById('commentsList');
        if (!container) return;
        
        if (courseComments.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <span class="fas fa-comment-slash"></span>
                    <p>No comments yet. Be the first to comment!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = courseComments.map(comment => this.generateCommentHTML(comment)).join('');
    }

    generateCommentHTML(comment) {
        const isOwn = comment.userEmail === this.currentUser.email;
        const isCreator = this.currentUser.email === this.course.creatorEmail;
        const canReply = isCreator && !isOwn;
        
        return `
            <div class="comment-item ${isOwn ? 'own-comment' : ''}">
                <div class="comment-avatar">${comment.userInitials}</div>
                <div class="comment-content">
                    <div class="comment-header">
                        <span class="comment-author">${comment.userName}</span>
                        <span class="comment-date">${this.formatDate(comment.timestamp)}</span>
                        ${isOwn ? `
                            <button class="btn-icon" onclick="videoPlayer.deleteComment('${comment.id}')">
                                <span class="fas fa-trash"></span>
                            </button>
                        ` : ''}
                    </div>
                    <div class="comment-text">${comment.text}</div>
                    ${comment.reply ? `
                        <div class="comment-reply">
                            <div class="reply-header">
                                <span class="fas fa-reply"></span>
                                <strong>${this.course.creatorName}</strong> replied:
                            </div>
                            <div class="reply-text">${comment.reply}</div>
                        </div>
                    ` : canReply ? `
                        <button class="btn-outline small" onclick="videoPlayer.showReplyBox('${comment.id}')">
                            <span class="fas fa-reply"></span>
                            Reply
                        </button>
                        <div class="reply-box" id="reply-${comment.id}" style="display: none;">
                            <textarea placeholder="Write your reply..."></textarea>
                            <div class="reply-actions">
                                <button class="btn-outline" onclick="videoPlayer.hideReplyBox('${comment.id}')">Cancel</button>
                                <button class="btn-primary" onclick="videoPlayer.submitReply('${comment.id}')">Reply</button>
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }

    postComment() {
        const input = document.getElementById('commentInput');
        const text = input ? input.value.trim() : '';
        
        if (!text) {
            showNotification('Please enter a comment', 'error');
            return;
        }

        const key = `${this.courseId}`;
        if (!this.comments[key]) {
            this.comments[key] = [];
        }

        const comment = {
            id: Date.now().toString(),
            userEmail: this.currentUser.email,
            userName: `${this.currentUser.firstName} ${this.currentUser.lastName}`,
            userInitials: this.currentUser.firstName.charAt(0) + this.currentUser.lastName.charAt(0),
            text: text,
            timestamp: Date.now(),
            reply: null
        };

        this.comments[key].push(comment);
        this.saveToStorage();
        
        input.value = '';
        this.loadComments();
        showNotification('Comment posted!', 'success');
    }

    cancelComment() {
        const input = document.getElementById('commentInput');
        if (input) input.value = '';
    }

    deleteComment(commentId) {
        if (confirm('Delete this comment?')) {
            const key = `${this.courseId}`;
            this.comments[key] = this.comments[key].filter(c => c.id !== commentId);
            this.saveToStorage();
            this.loadComments();
            showNotification('Comment deleted', 'success');
        }
    }

    showReplyBox(commentId) {
        const replyBox = document.getElementById(`reply-${commentId}`);
        if (replyBox) replyBox.style.display = 'block';
    }

    hideReplyBox(commentId) {
        const replyBox = document.getElementById(`reply-${commentId}`);
        if (replyBox) replyBox.style.display = 'none';
    }

    submitReply(commentId) {
        const replyBox = document.getElementById(`reply-${commentId}`);
        if (!replyBox) return;
        
        const textarea = replyBox.querySelector('textarea');
        const replyText = textarea ? textarea.value.trim() : '';
        
        if (!replyText) {
            showNotification('Please enter a reply', 'error');
            return;
        }

        const key = `${this.courseId}`;
        const comment = this.comments[key].find(c => c.id === commentId);
        
        if (comment) {
            comment.reply = replyText;
            this.saveToStorage();
            this.loadComments();
            showNotification('Reply posted!', 'success');
        }
    }

    loadReviews() {
        const key = `${this.courseId}`;
        const courseReviews = this.reviews[key] || [];
        
        const reviewCount = document.getElementById('reviewCount');
        if (reviewCount) reviewCount.textContent = courseReviews.length;
        
        const userReview = courseReviews.find(r => r.userEmail === this.currentUser.email);
        const addReviewSection = document.getElementById('addReviewSection');
        
        if (userReview && addReviewSection) {
            addReviewSection.innerHTML = `
                <div class="user-review-notice">
                    <span class="fas fa-check-circle"></span>
                    You have already reviewed this course (${userReview.rating}/5 stars)
                </div>
            `;
        }
        
        const container = document.getElementById('reviewsList');
        if (!container) return;
        
        if (courseReviews.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <span class="fas fa-star-half-alt"></span>
                    <p>No reviews yet. Be the first to review!</p>
                </div>
            `;
            return;
        }

        container.innerHTML = courseReviews.map(review => `
            <div class="review-item">
                <div class="review-header">
                    <div class="reviewer-info">
                        <div class="reviewer-avatar">${review.userInitials}</div>
                        <div>
                            <div class="reviewer-name">${review.userName}</div>
                            <div class="review-rating">
                                ${this.generateStars(review.rating)}
                                <span>${review.rating}/5</span>
                            </div>
                        </div>
                    </div>
                    <div class="review-date">${this.formatDate(review.timestamp)}</div>
                </div>
                <div class="review-text">${review.text}</div>
            </div>
        `).join('');
    }

    updateStarRating() {
        document.querySelectorAll('.star-btn').forEach((star, index) => {
            if (index < this.selectedRating) {
                star.classList.add('active');
            } else {
                star.classList.remove('active');
            }
        });
        const selectedRating = document.getElementById('selectedRating');
        if (selectedRating) selectedRating.textContent = this.selectedRating;
    }

    postReview() {
        const overallProgress = window.courseManager.getCourseProgress(
            this.currentUser.email,
            this.courseId
        );
        
        if (overallProgress < 50) {
            showNotification('You must watch at least 50% of the course to leave a review', 'error');
            return;
        }
        
        const reviewInput = document.getElementById('reviewInput');
        const text = reviewInput ? reviewInput.value.trim() : '';
        
        if (this.selectedRating === 0) {
            showNotification('Please select a rating', 'error');
            return;
        }
        
        if (!text) {
            showNotification('Please write a review', 'error');
            return;
        }

        const key = `${this.courseId}`;
        if (!this.reviews[key]) {
            this.reviews[key] = [];
        }

        const existingReview = this.reviews[key].find(r => r.userEmail === this.currentUser.email);
        if (existingReview) {
            showNotification('You have already reviewed this course', 'error');
            return;
        }

        const review = {
            id: Date.now().toString(),
            userEmail: this.currentUser.email,
            userName: `${this.currentUser.firstName} ${this.currentUser.lastName}`,
            userInitials: this.currentUser.firstName.charAt(0) + this.currentUser.lastName.charAt(0),
            rating: this.selectedRating,
            text: text,
            timestamp: Date.now()
        };

        this.reviews[key].push(review);
        this.saveToStorage();
        
        this.selectedRating = 0;
        this.updateStarRating();
        if (reviewInput) reviewInput.value = '';
        
        this.loadReviews();
        showNotification('Review submitted! Thank you!', 'success');
    }

    generateStars(rating) {
        let stars = '';
        for (let i = 1; i <= 5; i++) {
            stars += `<span class="star-display ${i <= rating ? 'active' : ''}">&#9733;</span>`;
        }
        return stars;
    }

    formatDate(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        
        if (days === 0) return 'Today';
        if (days === 1) return 'Yesterday';
        if (days < 7) return `${days} days ago`;
        return date.toLocaleDateString();
    }
}

let videoPlayer;
document.addEventListener('DOMContentLoaded', function() {
    videoPlayer = new VideoPlayer();
});

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;

    if (!document.querySelector('.notification-styles')) {
        const styles = document.createElement('style');
        styles.className = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                z-index: 3000;
                display: flex;
                align-items: center;
                gap: 1rem;
                max-width: 400px;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
                animation: slideIn 0.3s ease;
            }
            @keyframes slideIn {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
            .notification-success { background: rgba(16, 185, 129, 0.95); }
            .notification-error { background: rgba(239, 68, 68, 0.95); }
            .notification-info { background: rgba(139, 92, 246, 0.95); }
            .notification button {
                background: none;
                border: none;
                color: white;
                font-size: 1.2rem;
                cursor: pointer;
            }
        `;
        document.head.appendChild(styles);
    }

    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}
