// Authentication functionality - CLEANED
class AuthManager {
    constructor() {
        this.users = JSON.parse(localStorage.getItem('users')) || {};
        this.userProfiles = JSON.parse(localStorage.getItem('userProfiles')) || {};
        this.initializeDefaultUsers();
    }

    initializeDefaultUsers() {
        // 3 users: 1 admin, 1 teacher, 1 student
        if (!this.users['admin@skillshare.com']) {
            this.users['admin@skillshare.com'] = 'Admin@123';
            this.userProfiles['admin@skillshare.com'] = {
                firstName: 'Admin',
                lastName: 'User',
                email: 'admin@skillshare.com',
                userType: 'admin',
                contact: '',
                bio: 'Platform Administrator',
                status: 'active',
                joinDate: new Date().toISOString()
            };
        }

        if (!this.users['12@gmail.com']) {
            this.users['12@gmail.com'] = '!12345678';
            this.userProfiles['12@gmail.com'] = {
                firstName: 'Teacher',
                lastName: 'User',
                email: '12@gmail.com',
                userType: 'teacher',
                contact: '',
                bio: 'Teacher Account',
                status: 'active',
                joinDate: new Date().toISOString()
            };
        }

        if (!this.users['123@gmail.com']) {
            this.users['123@gmail.com'] = '123';
            this.userProfiles['123@gmail.com'] = {
                firstName: 'Student',
                lastName: 'User',
                email: '123@gmail.com',
                userType: 'student',
                contact: '',
                bio: 'Student Account',
                status: 'active',
                joinDate: new Date().toISOString()
            };
        }

        this.saveToStorage();
    }

    saveToStorage() {
        localStorage.setItem('users', JSON.stringify(this.users));
        localStorage.setItem('userProfiles', JSON.stringify(this.userProfiles));
    }

    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    validatePassword(password) {
        if (password.length < 3) return false;
        return true;
    }

    register(userData) {
        const { firstName, lastName, email, password, userType } = userData;

        if (this.users[email]) {
            throw new Error('Email already registered. Please login instead.');
        }

        if (!this.validatePassword(password)) {
            throw new Error('Password must be at least 3 characters.');
        }

        this.users[email] = password;
        this.userProfiles[email] = {
            firstName,
            lastName,
            email,
            userType,
            contact: '',
            bio: '',
            status: 'active',
            joinDate: new Date().toISOString()
        };

        this.saveToStorage();
        return this.userProfiles[email];
    }

    login(email, password) {
        if (!this.users[email] || this.users[email] !== password) {
            throw new Error('Invalid email or password.');
        }
        
        const user = this.userProfiles[email];
        if (user.status === 'suspended') {
            throw new Error('Your account has been suspended. Please contact admin.');
        }

        return user;
    }

    getCurrentUser() {
        const currentUserEmail = localStorage.getItem('currentUser');
        return currentUserEmail ? this.userProfiles[currentUserEmail] : null;
    }

    updateProfile(email, updates) {
        if (this.userProfiles[email]) {
            this.userProfiles[email] = { ...this.userProfiles[email], ...updates };
            this.saveToStorage();
            return this.userProfiles[email];
        }
        return null;
    }

    changePassword(email, oldPassword, newPassword) {
        if (this.users[email] !== oldPassword) {
            throw new Error('Current password is incorrect.');
        }
        this.users[email] = newPassword;
        this.saveToStorage();
        return true;
    }

    getAllUsers() {
        return Object.values(this.userProfiles);
    }

    getUsersByType(userType) {
        return Object.values(this.userProfiles).filter(u => u.userType === userType);
    }

    suspendUser(email) {
        if (this.userProfiles[email]) {
            this.userProfiles[email].status = 'suspended';
            this.saveToStorage();
            return true;
        }
        return false;
    }

    activateUser(email) {
        if (this.userProfiles[email]) {
            this.userProfiles[email].status = 'active';
            this.saveToStorage();
            return true;
        }
        return false;
    }

    deleteUser(email) {
        delete this.users[email];
        delete this.userProfiles[email];
        this.saveToStorage();
        return true;
    }

    logout() {
        localStorage.removeItem('currentUser');
        window.location.href = 'index.html';
    }
}

// Initialize auth manager
const authManager = new AuthManager();

// Password toggle functionality
function togglePassword(inputId, button) {
    const input = document.getElementById(inputId);
    const icon = button.querySelector('span');
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'fas fa-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'fas fa-eye';
    }
}

// DOM Event Handlers
function showLogin() {
    document.getElementById('loginModal').classList.remove('hidden');
    document.getElementById('signupModal').classList.add('hidden');
}

function showSignup() {
    document.getElementById('signupModal').classList.remove('hidden');
    document.getElementById('loginModal').classList.add('hidden');
}

function closeModals() {
    document.getElementById('loginModal').classList.add('hidden');
    document.getElementById('signupModal').classList.add('hidden');
}

function scrollToFeatures() {
    document.getElementById('features').scrollIntoView({ behavior: 'smooth' });
}

// Form Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const signupPassword = document.getElementById('signupPassword');

    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    if (signupForm) {
        signupForm.addEventListener('submit', handleSignup);
    }

    if (signupPassword) {
        signupPassword.addEventListener('input', validatePasswordRequirements);
    }

    // Check if user is already logged in
    const currentUser = authManager.getCurrentUser();
    if (currentUser && window.location.pathname.endsWith('index.html')) {
        redirectToDashboard(currentUser);
    }
});

function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;

    try {
        const user = authManager.login(email, password);
        localStorage.setItem('currentUser', email);
        
        showNotification('Login successful! Redirecting...', 'success');
        setTimeout(() => {
            redirectToDashboard(user);
        }, 1000);
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

function handleSignup(e) {
    e.preventDefault();
    
    const formData = {
        firstName: document.getElementById('firstName').value.trim(),
        lastName: document.getElementById('lastName').value.trim(),
        email: document.getElementById('signupEmail').value.trim(),
        password: document.getElementById('signupPassword').value,
        userType: document.getElementById('userType').value
    };

    // Validate password confirmation
    const confirmPassword = document.getElementById('confirmPassword').value;
    if (formData.password !== confirmPassword) {
        showNotification('Passwords do not match.', 'error');
        return;
    }

    try {
        const user = authManager.register(formData);
        localStorage.setItem('currentUser', formData.email);
        
        showNotification('Account created successfully!', 'success');
        setTimeout(() => {
            redirectToDashboard(user);
        }, 1000);
    } catch (error) {
        showNotification(error.message, 'error');
    }
}

function validatePasswordRequirements() {
    const password = this.value;
    const requirements = {
        length: password.length >= 3,
        number: /\d/.test(password),
        symbol: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(password)
    };

    Object.keys(requirements).forEach(req => {
        const element = document.getElementById(`req-${req}`);
        if (element) {
            if (requirements[req]) {
                element.style.color = '#10b981';
                element.style.fontWeight = '600';
            } else {
                element.style.color = '#64748b';
                element.style.fontWeight = 'normal';
            }
        }
    });
}

function redirectToDashboard(user) {
    if (user.userType === 'admin') {
        window.location.href = 'admin-dashboard.html';
    } else if (user.userType === 'teacher') {
        window.location.href = 'teacher-dashboard.html';
    } else {
        window.location.href = 'dashboard.html';
    }
}

function showNotification(message, type = 'info') {
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}
