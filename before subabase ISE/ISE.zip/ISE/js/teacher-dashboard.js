// Teacher Dashboard - FIXED THUMBNAIL DISPLAY
class TeacherDashboard {
    constructor() {
        this.currentUser = null;
        this.initialize();
    }

    initialize() {
        this.checkAuthentication();
        this.loadUserData();
        this.setupEventListeners();
        this.displayTeacherCourses();
        this.updateStats();
    }

    checkAuthentication() {
        const currentUserEmail = localStorage.getItem('currentUser');
        if (!currentUserEmail) {
            window.location.href = 'index.html';
            return;
        }
        
        const userProfiles = JSON.parse(localStorage.getItem('userProfiles') || '{}');
        this.currentUser = userProfiles[currentUserEmail];
        
        if (!this.currentUser || this.currentUser.userType !== 'teacher') {
            window.location.href = 'dashboard.html';
            return;
        }
    }

    loadUserData() {
        const userName = document.getElementById('userName');
        const teacherWelcomeName = document.getElementById('teacherWelcomeName');
        const userAvatar = document.getElementById('userAvatar');
        
        if (userName) userName.textContent = `${this.currentUser.firstName} ${this.currentUser.lastName}`;
        if (teacherWelcomeName) teacherWelcomeName.textContent = this.currentUser.firstName;
        
        const initials = this.currentUser.firstName.charAt(0) + this.currentUser.lastName.charAt(0);
        if (userAvatar) userAvatar.textContent = initials.toUpperCase();
    }

    setupEventListeners() {
        document.querySelectorAll('.sidebar-menu li').forEach(item => {
            if (item.onclick) return;
            
            item.addEventListener('click', () => {
                const page = item.getAttribute('data-page');
                if (page) {
                    this.showPage(page);
                }
            });
        });

        const userMenu = document.querySelector('.user-menu');
        const dropdown = document.getElementById('userDropdown');
        
        if (userMenu && dropdown) {
            userMenu.addEventListener('click', (e) => {
                e.stopPropagation();
                dropdown.classList.toggle('hidden');
            });

            document.addEventListener('click', () => {
                dropdown.classList.add('hidden');
            });
        }

        const searchInput = document.getElementById('globalSearch');
        if (searchInput) {
            searchInput.addEventListener('input', Utils.debounce(() => {
                this.handleSearch(searchInput.value);
            }, 300));
        }
    }

    showPage(pageId) {
        document.querySelectorAll('.page-content').forEach(page => {
            page.classList.remove('active');
            page.classList.add('hidden');
        });

        const targetPage = document.getElementById(`${pageId}-page`);
        if (targetPage) {
            targetPage.classList.remove('hidden');
            targetPage.classList.add('active');
        }

        document.querySelectorAll('.sidebar-menu li').forEach(item => {
            item.classList.remove('active');
        });
        
        const activeItem = document.querySelector(`[data-page="${pageId}"]`);
        if (activeItem) {
            activeItem.classList.add('active');
        }

        this.loadPageContent(pageId);
    }

    loadPageContent(pageId) {
        switch (pageId) {
            case 'teacher-dashboard':
                this.displayTeacherCourses();
                break;
            case 'my-courses-teacher':
                this.loadMyCoursesPage();
                break;
            case 'create-course':
                window.location.href = 'course-creation.html';
                break;
            case 'my-learning':
                this.loadMyLearningPage();
                break;
        }
    }

    // FIXED: Proper thumbnail rendering
    renderCourseThumbnail(course) {
        if (course.thumbnail && course.thumbnail.startsWith('data:image')) {
            return `<img src="${course.thumbnail}" alt="${course.title}" style="width: 100%; height: 100%; object-fit: cover;">`;
        } else {
            return course.thumbnail || '📚';
        }
    }

    displayTeacherCourses() {
        const container = document.getElementById('teacherCoursesGrid');
        if (!container) return;
        
        const myCourses = window.courseManager.getCreatedCourses(this.currentUser.email);
        
        if (myCourses.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-video"></i>
                    <h3>No courses created yet</h3>
                    <p>Start by creating your first course</p>
                    <button class="btn-primary" onclick="window.location.href='course-creation.html'">
                        <i class="fas fa-plus"></i>
                        Create Course
                    </button>
                </div>
            `;
            return;
        }

        container.innerHTML = myCourses.slice(0, 3).map(course => `
            <div class="course-card" onclick="teacherDashboard.viewCourseDetails(${course.id})">
                <div class="course-image">
                    ${this.renderCourseThumbnail(course)}
                </div>
                <div class="course-content">
                    <div class="course-title">${course.title}</div>
                    <div class="course-description">${course.description || 'No description'}</div>
                    <div class="course-stats">
                        <div class="course-stat">
                            <i class="fas fa-video"></i>
                            ${course.videos.length} videos
                        </div>
                        <div class="course-stat">
                            <i class="fas fa-calendar"></i>
                            ${new Date(course.createdDate).toLocaleDateString()}
                        </div>
                    </div>
                    <div class="course-actions">
                        <button class="btn-outline small" onclick="event.stopPropagation(); teacherDashboard.editCourse(${course.id})">
                            <i class="fas fa-edit"></i>
                            Edit
                        </button>
                        <button class="btn-outline small" onclick="event.stopPropagation(); teacherDashboard.deleteCourse(${course.id})">
                            <i class="fas fa-trash"></i>
                            Delete
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    loadMyCoursesPage() {
        const container = document.getElementById('teacherCoursesContainer');
        if (!container) return;
        
        const myCourses = window.courseManager.getCreatedCourses(this.currentUser.email);
        
        if (myCourses.length === 0) {
            container.innerHTML = `
                <div class="empty-state large">
                    <i class="fas fa-video"></i>
                    <h2>No Courses Created</h2>
                    <p>Start creating courses to share your knowledge</p>
                    <button class="btn-primary" onclick="window.location.href='course-creation.html'">
                        <i class="fas fa-plus"></i>
                        Create Course
                    </button>
                </div>
            `;
            return;
        }

        container.innerHTML = `
            <div class="page-actions">
                <button class="btn-primary" onclick="window.location.href='course-creation.html'">
                    <i class="fas fa-plus"></i>
                    Create New Course
                </button>
            </div>
            <div class="courses-management-grid">
                ${myCourses.map(course => `
                    <div class="course-management-card">
                        <div class="course-management-header">
                            <div class="course-basic-info">
                                <div class="course-thumbnail">${this.renderCourseThumbnail(course)}</div>
                                <div class="course-details">
                                    <h3>${course.title}</h3>
                                    <p class="course-category">${course.category}</p>
                                    <div class="course-meta">
                                        <span>${course.videos.length} videos</span>
                                        <span>Created: ${new Date(course.createdDate).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="course-management-actions">
                            <button class="btn-outline" onclick="teacherDashboard.editCourse(${course.id})">
                                <i class="fas fa-edit"></i>
                                Edit Course
                            </button>
                            <button class="btn-outline" onclick="teacherDashboard.viewCourseDetails(${course.id})">
                                <i class="fas fa-eye"></i>
                                View Details
                            </button>
                            <button class="btn-outline" onclick="teacherDashboard.deleteCourse(${course.id})">
                                <i class="fas fa-trash"></i>
                                Delete
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }

    editCourse(courseId) {
        window.location.href = `course-creation.html?courseId=${courseId}`;
    }

    viewCourseDetails(courseId) {
        const course = window.courseManager.getCourse(courseId);
        if (!course) return;

        const modal = document.createElement('div');
        modal.id = 'courseDetailsModal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content large">
                <div class="modal-header">
                    <h2>${course.title}</h2>
                    <button class="close-btn" onclick="document.getElementById('courseDetailsModal').remove()">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="modal-course-header">
                        <div class="modal-course-image">
                            ${this.renderCourseThumbnail(course)}
                        </div>
                        <div class="modal-course-info">
                            <h3>${course.title}</h3>
                            <p class="course-instructor">by ${course.creatorName}</p>
                            <div class="course-meta">
                                <span><i class="fas fa-video"></i> ${course.videos.length} videos</span>
                                <span><i class="fas fa-calendar"></i> ${new Date(course.createdDate).toLocaleDateString()}</span>
                                <span><i class="fas fa-tag"></i> ${course.category}</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="modal-course-description">
                        <h4>About this course</h4>
                        <p>${course.description || 'No description available'}</p>
                    </div>

                    <div class="modal-course-description">
                        <h4>Course Videos</h4>
                        <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                            ${course.videos.map((video, index) => `
                                <div style="background: var(--surface-color); padding: 0.75rem; border-radius: 8px; border: 1px solid var(--border-light);">
                                    <strong style="color: var(--text-primary);">${index + 1}. ${video.name}</strong>
                                </div>
                            `).join('')}
                        </div>
                    </div>

                    <div class="modal-course-actions" style="margin-top: 2rem;">
                        <button class="btn-primary" onclick="teacherDashboard.editCourse(${course.id}); document.getElementById('courseDetailsModal').remove()">
                            <i class="fas fa-edit"></i>
                            Edit Course
                        </button>
                        <button class="btn-outline" onclick="teacherDashboard.deleteCourse(${course.id}); document.getElementById('courseDetailsModal').remove()">
                            <i class="fas fa-trash"></i>
                            Delete Course
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
    }

    deleteCourse(courseId) {
        const course = window.courseManager.getCourse(courseId);
        if (!course) return;

        if (confirm(`Are you sure you want to delete "${course.title}"? This action cannot be undone.`)) {
            window.courseManager.deleteCourse(courseId);
            
            if (typeof searchManager !== 'undefined') {
                searchManager.loadAllCourses();
            }
            
            showNotification('Course deleted successfully', 'success');
            this.displayTeacherCourses();
            this.loadMyCoursesPage();
            this.updateStats();
        }
    }

    loadMyLearningPage() {
        const container = document.getElementById('myLearningGrid');
        const enrolledCourses = window.courseManager.getUserCourses(this.currentUser.email);
        
        if (!container) return;

        if (enrolledCourses.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-book-open"></i>
                    <h3>No courses enrolled</h3>
                    <p>Search and enroll in courses to start learning</p>
                </div>
            `;
            return;
        }

        container.innerHTML = enrolledCourses.map(course => `
            <div class="course-card" onclick="teacherDashboard.openCourse(${course.id})">
                <div class="course-image">${this.renderCourseThumbnail(course)}</div>
                <div class="course-content">
                    <div class="course-title">${course.title}</div>
                    <div class="course-instructor">
                        <i class="fas fa-user"></i>
                        ${course.creatorName}
                    </div>
                    <button class="continue-btn" onclick="event.stopPropagation(); teacherDashboard.openCourse(${course.id})">
                        Continue Learning
                    </button>
                </div>
            </div>
        `).join('');
    }

    openCourse(courseId) {
        const course = window.courseManager.getCourse(courseId);
        if (!course || course.videos.length === 0) {
            showNotification('This course has no videos yet', 'error');
            return;
        }
        
        window.location.href = `video-player.html?courseId=${courseId}`;
    }

    updateStats() {
        const myCourses = window.courseManager.getCreatedCourses(this.currentUser.email);
        const teacherCoursesEl = document.getElementById('teacherCourses');
        if (teacherCoursesEl) teacherCoursesEl.textContent = myCourses.length;
        
        const totalVideos = myCourses.reduce((sum, course) => sum + course.videos.length, 0);
        const totalStudentsEl = document.getElementById('totalStudents');
        const avgRatingEl = document.getElementById('avgRating');
        const totalHoursEl = document.getElementById('totalHours');
        
        if (totalStudentsEl) totalStudentsEl.textContent = '0';
        if (avgRatingEl) avgRatingEl.textContent = '0.0';
        if (totalHoursEl) totalHoursEl.textContent = totalVideos;
    }

    handleSearch(query) {
        if (!query.trim()) {
            if (typeof searchManager !== 'undefined') {
                searchManager.hideSearchResults();
            }
            return;
        }

        if (typeof searchManager !== 'undefined') {
            searchManager.performSearch(query);
        }
    }
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('currentUser');
        window.location.href = 'index.html';
    }
}

let teacherDashboard;
document.addEventListener('DOMContentLoaded', function() {
    teacherDashboard = new TeacherDashboard();
});

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;

    if (!document.querySelector('.notification-styles')) {
        const styles = document.createElement('style');
        styles.className = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                z-index: 3000;
                display: flex;
                align-items: center;
                gap: 1rem;
                max-width: 400px;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
            }
            .notification-success { background: rgba(16, 185, 129, 0.9); }
            .notification-error { background: rgba(239, 68, 68, 0.9); }
            .notification-info { background: rgba(59, 130, 246, 0.9); }
            .notification button {
                background: none;
                border: none;
                color: white;
                font-size: 1.2rem;
                cursor: pointer;
            }
        `;
        document.head.appendChild(styles);
    }

    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}