// Comprehensive IndexedDB Database System for SkillShare
// Handles all offline data storage for users, courses, videos, ratings, messages, and analytics

class SkillShareDB {
    constructor() {
        this.dbName = 'SkillShareDB';
        this.dbVersion = 2;
        this.db = null;
        this.isReady = false;
        this.readyCallbacks = [];
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onerror = (event) => {
                console.error('IndexedDB error:', event.target.error);
                reject(event.target.error);
            };

            request.onsuccess = (event) => {
                this.db = event.target.result;
                this.isReady = true;
                console.log('IndexedDB initialized successfully');
                this.readyCallbacks.forEach(cb => cb());
                resolve(this.db);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Users store
                if (!db.objectStoreNames.contains('users')) {
                    const usersStore = db.createObjectStore('users', { keyPath: 'email' });
                    usersStore.createIndex('userType', 'userType', { unique: false });
                    usersStore.createIndex('status', 'status', { unique: false });
                }

                // Courses store
                if (!db.objectStoreNames.contains('courses')) {
                    const coursesStore = db.createObjectStore('courses', { keyPath: 'id', autoIncrement: true });
                    coursesStore.createIndex('creatorEmail', 'creatorEmail', { unique: false });
                    coursesStore.createIndex('category', 'category', { unique: false });
                    coursesStore.createIndex('published', 'published', { unique: false });
                }

                // Videos store (for large video blobs)
                if (!db.objectStoreNames.contains('videos')) {
                    db.createObjectStore('videos', { keyPath: 'id' });
                }

                // Thumbnails store
                if (!db.objectStoreNames.contains('thumbnails')) {
                    db.createObjectStore('thumbnails', { keyPath: 'id' });
                }

                // Enrollments store
                if (!db.objectStoreNames.contains('enrollments')) {
                    const enrollStore = db.createObjectStore('enrollments', { keyPath: 'id', autoIncrement: true });
                    enrollStore.createIndex('userEmail', 'userEmail', { unique: false });
                    enrollStore.createIndex('courseId', 'courseId', { unique: false });
                }

                // Video progress store
                if (!db.objectStoreNames.contains('videoProgress')) {
                    const progressStore = db.createObjectStore('videoProgress', { keyPath: 'id' });
                    progressStore.createIndex('userEmail', 'userEmail', { unique: false });
                    progressStore.createIndex('courseId', 'courseId', { unique: false });
                }

                // Ratings store
                if (!db.objectStoreNames.contains('ratings')) {
                    const ratingsStore = db.createObjectStore('ratings', { keyPath: 'id', autoIncrement: true });
                    ratingsStore.createIndex('courseId', 'courseId', { unique: false });
                    ratingsStore.createIndex('videoId', 'videoId', { unique: false });
                    ratingsStore.createIndex('userEmail', 'userEmail', { unique: false });
                }

                // Reviews store
                if (!db.objectStoreNames.contains('reviews')) {
                    const reviewsStore = db.createObjectStore('reviews', { keyPath: 'id', autoIncrement: true });
                    reviewsStore.createIndex('courseId', 'courseId', { unique: false });
                    reviewsStore.createIndex('userEmail', 'userEmail', { unique: false });
                }

                // Messages store
                if (!db.objectStoreNames.contains('messages')) {
                    const messagesStore = db.createObjectStore('messages', { keyPath: 'id', autoIncrement: true });
                    messagesStore.createIndex('conversationId', 'conversationId', { unique: false });
                    messagesStore.createIndex('senderEmail', 'senderEmail', { unique: false });
                    messagesStore.createIndex('receiverEmail', 'receiverEmail', { unique: false });
                    messagesStore.createIndex('timestamp', 'timestamp', { unique: false });
                }

                // Conversations store
                if (!db.objectStoreNames.contains('conversations')) {
                    const convStore = db.createObjectStore('conversations', { keyPath: 'id', autoIncrement: true });
                    convStore.createIndex('participants', 'participants', { unique: false, multiEntry: true });
                }

                // Notes store (shared PDFs, images, links)
                if (!db.objectStoreNames.contains('notes')) {
                    const notesStore = db.createObjectStore('notes', { keyPath: 'id', autoIncrement: true });
                    notesStore.createIndex('courseId', 'courseId', { unique: false });
                    notesStore.createIndex('userEmail', 'userEmail', { unique: false });
                }

                // Notifications store
                if (!db.objectStoreNames.contains('notifications')) {
                    const notifStore = db.createObjectStore('notifications', { keyPath: 'id', autoIncrement: true });
                    notifStore.createIndex('userEmail', 'userEmail', { unique: false });
                    notifStore.createIndex('read', 'read', { unique: false });
                }

                // Activity logs store (for admin analytics)
                if (!db.objectStoreNames.contains('activityLogs')) {
                    const logsStore = db.createObjectStore('activityLogs', { keyPath: 'id', autoIncrement: true });
                    logsStore.createIndex('userEmail', 'userEmail', { unique: false });
                    logsStore.createIndex('action', 'action', { unique: false });
                    logsStore.createIndex('timestamp', 'timestamp', { unique: false });
                }

                // Certificates store
                if (!db.objectStoreNames.contains('certificates')) {
                    const certsStore = db.createObjectStore('certificates', { keyPath: 'id', autoIncrement: true });
                    certsStore.createIndex('userEmail', 'userEmail', { unique: false });
                    certsStore.createIndex('courseId', 'courseId', { unique: false });
                }

                console.log('IndexedDB schema created/upgraded');
            };
        });
    }

    onReady(callback) {
        if (this.isReady) {
            callback();
        } else {
            this.readyCallbacks.push(callback);
        }
    }

    // Generic CRUD operations
    async add(storeName, data) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.add(data);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async put(storeName, data) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.put(data);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async get(storeName, key) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.get(key);

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async getAll(storeName) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.getAll();

            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error);
        });
    }

    async delete(storeName, key) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.delete(key);

            request.onsuccess = () => resolve(true);
            request.onerror = () => reject(request.error);
        });
    }

    async getByIndex(storeName, indexName, value) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            const index = store.index(indexName);
            const request = index.getAll(value);

            request.onsuccess = () => resolve(request.result || []);
            request.onerror = () => reject(request.error);
        });
    }

    async count(storeName) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            const request = store.count();

            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async clear(storeName) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            const request = store.clear();

            request.onsuccess = () => resolve(true);
            request.onerror = () => reject(request.error);
        });
    }
}

// Initialize the global database instance
const skillShareDB = new SkillShareDB();

// Messaging System
class MessagingSystem {
    constructor(db) {
        this.db = db;
    }

    async createConversation(participants) {
        const conversation = {
            participants: participants.sort(),
            createdAt: Date.now(),
            lastMessageAt: Date.now(),
            lastMessage: ''
        };
        return await this.db.add('conversations', conversation);
    }

    async getOrCreateConversation(user1, user2) {
        const conversations = await this.db.getAll('conversations');
        const existing = conversations.find(c => 
            c.participants.includes(user1) && c.participants.includes(user2)
        );
        
        if (existing) return existing;
        
        const id = await this.createConversation([user1, user2]);
        return { id, participants: [user1, user2].sort(), createdAt: Date.now() };
    }

    async sendMessage(conversationId, senderEmail, content, attachments = []) {
        const message = {
            conversationId,
            senderEmail,
            content,
            attachments, // [{type: 'pdf'|'image'|'link', data: base64|url, name: string}]
            timestamp: Date.now(),
            read: false
        };
        
        const id = await this.db.add('messages', message);
        
        // Update conversation
        const conv = await this.db.get('conversations', conversationId);
        if (conv) {
            conv.lastMessageAt = Date.now();
            conv.lastMessage = content.substring(0, 100);
            await this.db.put('conversations', conv);
        }
        
        return { ...message, id };
    }

    async getMessages(conversationId) {
        return await this.db.getByIndex('messages', 'conversationId', conversationId);
    }

    async getUserConversations(userEmail) {
        const allConversations = await this.db.getAll('conversations');
        return allConversations.filter(c => c.participants.includes(userEmail));
    }

    async markAsRead(messageId) {
        const message = await this.db.get('messages', messageId);
        if (message) {
            message.read = true;
            await this.db.put('messages', message);
        }
    }

    async getUnreadCount(userEmail) {
        const conversations = await this.getUserConversations(userEmail);
        let count = 0;
        
        for (const conv of conversations) {
            const messages = await this.getMessages(conv.id);
            count += messages.filter(m => !m.read && m.senderEmail !== userEmail).length;
        }
        
        return count;
    }
}

// Analytics System
class AnalyticsSystem {
    constructor(db) {
        this.db = db;
    }

    async logActivity(userEmail, action, details = {}) {
        const log = {
            userEmail,
            action,
            details,
            timestamp: Date.now()
        };
        return await this.db.add('activityLogs', log);
    }

    async getUserActivity(userEmail, limit = 50) {
        const logs = await this.db.getByIndex('activityLogs', 'userEmail', userEmail);
        return logs.sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
    }

    async getActivityStats(days = 30) {
        const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
        const allLogs = await this.db.getAll('activityLogs');
        const recentLogs = allLogs.filter(l => l.timestamp >= cutoff);
        
        const stats = {
            totalActivities: recentLogs.length,
            uniqueUsers: new Set(recentLogs.map(l => l.userEmail)).size,
            actionBreakdown: {},
            dailyActivity: {}
        };
        
        recentLogs.forEach(log => {
            // Action breakdown
            stats.actionBreakdown[log.action] = (stats.actionBreakdown[log.action] || 0) + 1;
            
            // Daily activity
            const day = new Date(log.timestamp).toDateString();
            stats.dailyActivity[day] = (stats.dailyActivity[day] || 0) + 1;
        });
        
        return stats;
    }

    async getCourseAnalytics(courseId) {
        const enrollments = await this.db.getByIndex('enrollments', 'courseId', courseId);
        const progress = await this.db.getByIndex('videoProgress', 'courseId', courseId);
        const ratings = await this.db.getByIndex('ratings', 'courseId', courseId);
        const reviews = await this.db.getByIndex('reviews', 'courseId', courseId);
        
        // Calculate completion rates
        const uniqueStudents = new Set(progress.map(p => p.userEmail));
        const completedStudents = new Set();
        
        uniqueStudents.forEach(email => {
            const studentProgress = progress.filter(p => p.userEmail === email);
            const avgProgress = studentProgress.reduce((sum, p) => sum + p.percentage, 0) / studentProgress.length;
            if (avgProgress >= 90) completedStudents.add(email);
        });
        
        // Average rating
        const avgRating = ratings.length > 0 
            ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length 
            : 0;
        
        // Drop-off analysis
        const videoProgressMap = {};
        progress.forEach(p => {
            if (!videoProgressMap[p.videoId]) {
                videoProgressMap[p.videoId] = [];
            }
            videoProgressMap[p.videoId].push(p.percentage);
        });
        
        const dropOffPoints = Object.entries(videoProgressMap).map(([videoId, percentages]) => ({
            videoId,
            avgCompletion: percentages.reduce((a, b) => a + b, 0) / percentages.length,
            viewers: percentages.length
        })).sort((a, b) => a.avgCompletion - b.avgCompletion);
        
        return {
            totalEnrollments: enrollments.length,
            activeStudents: uniqueStudents.size,
            completedStudents: completedStudents.size,
            completionRate: uniqueStudents.size > 0 ? (completedStudents.size / uniqueStudents.size) * 100 : 0,
            averageRating: avgRating,
            totalRatings: ratings.length,
            totalReviews: reviews.length,
            dropOffPoints: dropOffPoints.slice(0, 5)
        };
    }

    async getTeacherAnalytics(teacherEmail) {
        const courses = await this.db.getByIndex('courses', 'creatorEmail', teacherEmail);
        
        let totalEnrollments = 0;
        let totalRatings = 0;
        let ratingSum = 0;
        let courseStats = [];
        
        for (const course of courses) {
            const analytics = await this.getCourseAnalytics(course.id);
            totalEnrollments += analytics.totalEnrollments;
            totalRatings += analytics.totalRatings;
            ratingSum += analytics.averageRating * analytics.totalRatings;
            
            courseStats.push({
                courseId: course.id,
                title: course.title,
                ...analytics
            });
        }
        
        return {
            totalCourses: courses.length,
            totalEnrollments,
            averageRating: totalRatings > 0 ? ratingSum / totalRatings : 0,
            courseStats
        };
    }

    async getPlatformAnalytics() {
        const users = await this.db.getAll('users');
        const courses = await this.db.getAll('courses');
        const enrollments = await this.db.getAll('enrollments');
        const activityStats = await this.getActivityStats(30);
        
        const students = users.filter(u => u.userType === 'student');
        const teachers = users.filter(u => u.userType === 'teacher');
        const admins = users.filter(u => u.userType === 'admin');
        
        // Growth calculation (last 7 days vs previous 7 days)
        const now = Date.now();
        const oneWeek = 7 * 24 * 60 * 60 * 1000;
        const recentUsers = users.filter(u => u.joinDate && (now - new Date(u.joinDate).getTime()) < oneWeek);
        const previousUsers = users.filter(u => {
            const time = u.joinDate ? now - new Date(u.joinDate).getTime() : 0;
            return time >= oneWeek && time < (2 * oneWeek);
        });
        
        const userGrowth = previousUsers.length > 0 
            ? ((recentUsers.length - previousUsers.length) / previousUsers.length) * 100 
            : 100;
        
        return {
            totalUsers: users.length,
            totalStudents: students.length,
            totalTeachers: teachers.length,
            totalAdmins: admins.length,
            totalCourses: courses.length,
            publishedCourses: courses.filter(c => c.published).length,
            totalEnrollments: enrollments.length,
            userGrowth,
            ...activityStats
        };
    }
}

// Notification System
class NotificationSystem {
    constructor(db) {
        this.db = db;
    }

    async createNotification(userEmail, type, title, message, link = null) {
        const notification = {
            userEmail,
            type, // 'course_update', 'message', 'review', 'enrollment', 'system'
            title,
            message,
            link,
            read: false,
            createdAt: Date.now()
        };
        return await this.db.add('notifications', notification);
    }

    async getUserNotifications(userEmail, limit = 20) {
        const notifications = await this.db.getByIndex('notifications', 'userEmail', userEmail);
        return notifications.sort((a, b) => b.createdAt - a.createdAt).slice(0, limit);
    }

    async getUnreadCount(userEmail) {
        const notifications = await this.db.getByIndex('notifications', 'userEmail', userEmail);
        return notifications.filter(n => !n.read).length;
    }

    async markAsRead(notificationId) {
        const notification = await this.db.get('notifications', notificationId);
        if (notification) {
            notification.read = true;
            await this.db.put('notifications', notification);
        }
    }

    async markAllAsRead(userEmail) {
        const notifications = await this.db.getByIndex('notifications', 'userEmail', userEmail);
        for (const notification of notifications) {
            if (!notification.read) {
                notification.read = true;
                await this.db.put('notifications', notification);
            }
        }
    }

    async deleteNotification(notificationId) {
        await this.db.delete('notifications', notificationId);
    }
}

// Certificate System
class CertificateSystem {
    constructor(db) {
        this.db = db;
    }

    async issueCertificate(userEmail, courseId, courseName, instructorName) {
        const certificate = {
            userEmail,
            courseId,
            courseName,
            instructorName,
            issuedAt: Date.now(),
            certificateNumber: this.generateCertificateNumber()
        };
        return await this.db.add('certificates', certificate);
    }

    generateCertificateNumber() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        let result = 'CERT-';
        for (let i = 0; i < 12; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    async getUserCertificates(userEmail) {
        return await this.db.getByIndex('certificates', 'userEmail', userEmail);
    }

    async getCertificate(certificateId) {
        return await this.db.get('certificates', certificateId);
    }

    async verifyCertificate(certificateNumber) {
        const certs = await this.db.getAll('certificates');
        return certs.find(c => c.certificateNumber === certificateNumber);
    }
}

// Initialize all systems after DB is ready
let messagingSystem, analyticsSystem, notificationSystem, certificateSystem;

skillShareDB.init().then(() => {
    messagingSystem = new MessagingSystem(skillShareDB);
    analyticsSystem = new AnalyticsSystem(skillShareDB);
    notificationSystem = new NotificationSystem(skillShareDB);
    certificateSystem = new CertificateSystem(skillShareDB);
    console.log('All database systems initialized');
}).catch(err => {
    console.error('Failed to initialize database:', err);
});
