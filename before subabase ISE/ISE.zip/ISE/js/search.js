// Enhanced Search System with Advanced Filtering
class SearchManager {
    constructor() {
        this.allCourses = [];
        this.filteredCourses = [];
        this.searchTimeout = null;
        this.currentFilters = {
            category: 'all',
            rating: 'all',
            duration: 'all',
            level: 'all',
            sortBy: 'relevance'
        };
        this.initialize();
    }

    initialize() {
    this.loadAllCourses();
    this.setupSearchListeners();
    // displayDefaultCourses() not needed anymore
}

    loadAllCourses() {
    // Load REAL courses from courseManager instead of mock data
    const realCourses = window.courseManager.getAllCourses();
    
    console.log('Loading courses for search:', realCourses.length);
    
    // Transform real courses to match search display format
    this.allCourses = realCourses.map(course => {
        // Get rating stats if ratingManager exists
        let avgRating = 4.5;
        let ratingCount = 0;
        
        if (typeof ratingManager !== 'undefined') {
            avgRating = ratingManager.getCourseAverageRating(course.id) || 4.5;
            ratingCount = ratingManager.getCourseRatingCount(course.id);
        }
        
        // Calculate duration from videos
        const totalMinutes = course.videos.length * 15; // Estimate 15min per video
        const hours = Math.floor(totalMinutes / 60);
        const duration = hours > 0 ? `${hours}h` : `${totalMinutes}m`;
        
        return {
            id: course.id,
            title: course.title,
            instructor: course.creatorName,
            instructorInitials: course.creatorName.split(' ').map(n => n[0]).join(''),
            instructorId: course.creatorEmail,
            category: course.category || 'General',
            level: course.level || 'Beginner',
            description: course.description || 'No description available',
            duration: duration,
            rating: avgRating,
            ratingCount: ratingCount,
            students: ratingCount, // Use rating count as student estimate
            thumbnail: course.thumbnail || '📚',
            price: 0,
            tags: [course.category || 'General'],
            lastUpdated: course.createdDate,
            language: 'English',
            enrolled: false
        };
    });

    // Load enrolled courses from localStorage
    const currentUserEmail = localStorage.getItem('currentUser');
    if (currentUserEmail) {
        const enrollments = JSON.parse(localStorage.getItem('enrollments') || '{}');
        const userEnrollments = enrollments[currentUserEmail] || [];
        
        this.allCourses.forEach(course => {
            course.enrolled = userEnrollments.includes(course.id);
        });
    }

    this.filteredCourses = [...this.allCourses];
    console.log('Search system loaded:', this.allCourses.length, 'courses');
}

    setupSearchListeners() {
        const searchInput = document.getElementById('globalSearch');
        if (!searchInput) return;

        // Real-time search with debouncing
        searchInput.addEventListener('input', (e) => {
            clearTimeout(this.searchTimeout);
            const query = e.target.value.trim();
            
            if (query.length === 0) {
                this.hideSearchResults();
                return;
            }

            // Show search results immediately with loading state
            this.showSearchResults();
            
            // Debounce the actual search
            this.searchTimeout = setTimeout(() => {
                this.performSearch(query);
            }, 300);
        });

        // Show search overlay when clicking on search input (discover mode)
        searchInput.addEventListener('focus', (e) => {
            const query = e.target.value.trim();
            if (query.length === 0) {
                this.showDiscoverMode();
            }
        });

        // Handle Enter key
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                clearTimeout(this.searchTimeout);
                const query = e.target.value.trim();
                if (query.length > 0) {
                    this.performSearch(query);
                }
            }
        });

        // Setup filter listeners
        this.setupFilterListeners();
    }

    setupFilterListeners() {
        // Category filter
        const categoryBtns = document.querySelectorAll('.category-filter-btn');
        categoryBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                categoryBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentFilters.category = btn.dataset.category;
                this.applyFilters();
            });
        });

        // Other filter dropdowns
        const filterSelects = document.querySelectorAll('.filter-select');
        filterSelects.forEach(select => {
            select.addEventListener('change', (e) => {
                const filterType = e.target.dataset.filter;
                this.currentFilters[filterType] = e.target.value;
                this.applyFilters();
            });
        });

        // Sort dropdown
        const sortSelect = document.getElementById('sortBy');
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                this.currentFilters.sortBy = e.target.value;
                this.applyFilters();
            });
        }

        // Clear filters button
        const clearFiltersBtn = document.getElementById('clearFilters');
        if (clearFiltersBtn) {
            clearFiltersBtn.addEventListener('click', () => {
                this.clearAllFilters();
            });
        }
    }

    performSearch(query) {
        const lowerQuery = query.toLowerCase();
        
        // Search in multiple fields
        this.filteredCourses = this.allCourses.filter(course => {
            const titleMatch = course.title.toLowerCase().includes(lowerQuery);
            const instructorMatch = course.instructor.toLowerCase().includes(lowerQuery);
            const categoryMatch = course.category.toLowerCase().includes(lowerQuery);
            const descriptionMatch = course.description.toLowerCase().includes(lowerQuery);
            const tagsMatch = course.tags.some(tag => tag.toLowerCase().includes(lowerQuery));
            
            return titleMatch || instructorMatch || categoryMatch || descriptionMatch || tagsMatch;
        });

        // Apply current filters
        this.applyFilters();
        
        // Display search results
        this.displaySearchResults(query);
    }

    applyFilters() {
        let filtered = [...this.filteredCourses];

        // Category filter
        if (this.currentFilters.category !== 'all') {
            filtered = filtered.filter(course => 
                course.category === this.currentFilters.category
            );
        }

        // Rating filter
        if (this.currentFilters.rating !== 'all') {
            const minRating = parseFloat(this.currentFilters.rating);
            filtered = filtered.filter(course => course.rating >= minRating);
        }

        // Duration filter
        if (this.currentFilters.duration !== 'all') {
            filtered = filtered.filter(course => {
                const hours = parseInt(course.duration);
                switch(this.currentFilters.duration) {
                    case 'short': return hours < 10;
                    case 'medium': return hours >= 10 && hours <= 30;
                    case 'long': return hours > 30;
                    default: return true;
                }
            });
        }

        // Level filter
        if (this.currentFilters.level !== 'all') {
            filtered = filtered.filter(course => 
                course.level === this.currentFilters.level
            );
        }

        // Sort
        filtered = this.sortCourses(filtered, this.currentFilters.sortBy);

        this.filteredCourses = filtered;
        
        // Check if we're in search mode or discover mode
        const searchInput = document.getElementById('globalSearch');
        const query = searchInput ? searchInput.value.trim() : '';
        
        if (query.length > 0) {
            this.displaySearchResults(query);
        } else {
            this.displayDiscoverCourses();
        }
    }

    sortCourses(courses, sortBy) {
        const sorted = [...courses];
        
        switch(sortBy) {
            case 'rating':
                sorted.sort((a, b) => b.rating - a.rating);
                break;
            case 'students':
                sorted.sort((a, b) => b.students - a.students);
                break;
            case 'newest':
                sorted.sort((a, b) => new Date(b.lastUpdated) - new Date(a.lastUpdated));
                break;
            case 'duration-asc':
                sorted.sort((a, b) => parseInt(a.duration) - parseInt(b.duration));
                break;
            case 'duration-desc':
                sorted.sort((a, b) => parseInt(b.duration) - parseInt(a.duration));
                break;
            case 'relevance':
            default:
                // Keep current order (relevance based on search)
                break;
        }
        
        return sorted;
    }

    showSearchResults() {
        const searchOverlay = document.getElementById('searchResultsOverlay');
        if (searchOverlay) {
            searchOverlay.classList.remove('hidden');
            // Update header for search mode
            const headerInfo = document.querySelector('.search-header-info h2');
            if (headerInfo) {
                headerInfo.innerHTML = 'Search Results for "<span id="searchQueryText">...</span>"';
            }
        }
    }

    hideSearchResults() {
        const searchOverlay = document.getElementById('searchResultsOverlay');
        if (searchOverlay) {
            searchOverlay.classList.add('hidden');
        }
    }

    showDiscoverMode() {
        const searchOverlay = document.getElementById('searchResultsOverlay');
        if (searchOverlay) {
            searchOverlay.classList.remove('hidden');
            // Update header for discover mode
            const headerInfo = document.querySelector('.search-header-info h2');
            if (headerInfo) {
                headerInfo.innerHTML = 'Discover Courses';
            }
            // Show all courses
            this.filteredCourses = [...this.allCourses];
            this.displayDiscoverCourses();
        }
    }

    displayDefaultCourses() {
        // This will be handled by the dashboard's default course display
        this.filteredCourses = [...this.allCourses];
    }

    displaySearchResults(query) {
        const resultsContainer = document.getElementById('searchResultsContainer');
        const resultsCount = document.getElementById('searchResultsCount');
        const searchQuery = document.getElementById('searchQueryText');
        
        if (!resultsContainer) return;

        // Update header
        if (searchQuery) searchQuery.textContent = query;
        if (resultsCount) resultsCount.textContent = `${this.filteredCourses.length} results`;

        // Display courses
        if (this.filteredCourses.length === 0) {
            resultsContainer.innerHTML = `
                <div class="no-results">
                    <i class="fas fa-search"></i>
                    <h3>No courses found</h3>
                    <p>Try different keywords or clear your filters</p>
                    <button class="btn-outline" onclick="searchManager.clearSearchAndFilters()">
                        Clear Search
                    </button>
                </div>
            `;
            return;
        }

        this.renderCourseCards(resultsContainer);
    }

    displayDiscoverCourses() {
        const resultsContainer = document.getElementById('searchResultsContainer');
        const resultsCount = document.getElementById('searchResultsCount');
        
        if (!resultsContainer) return;

        // Update header for discover mode
        if (resultsCount) resultsCount.textContent = `${this.filteredCourses.length} courses available`;

        // Display all courses
        this.renderCourseCards(resultsContainer);
    }

    // UPDATE the renderCourseCards method in search.js

renderCourseCards(container) {
    container.innerHTML = this.filteredCourses.map(course => `
        <div class="search-course-card" onclick="searchManager.viewCourse(${course.id})">
            <div class="search-course-image">
                ${course.thumbnail}
                ${course.enrolled ? '<div class="enrolled-badge">Enrolled</div>' : ''}
            </div>
            <div class="search-course-content">
                <div class="search-course-header">
                    <div>
                        <h3 class="search-course-title">${course.title}</h3>
                        <p class="search-course-instructor">
                            <i class="fas fa-user"></i>
                            ${course.instructor}
                        </p>
                    </div>
                    
                    <!-- UPDATE RATING DISPLAY TO USE RATING MANAGER -->
                    <div class="search-course-rating">
                        ${typeof ratingManager !== 'undefined' ? 
                            ratingManager.generateStarRatingHTML(course.id, null, 'medium') : 
                            `
                            <span class="rating-value">${course.rating}</span>
                            <div class="stars">
                                ${this.generateStars(course.rating)}
                            </div>
                            <span class="rating-count">(${course.ratingCount.toLocaleString()})</span>
                            `
                        }
                    </div>
                </div>
                <p class="search-course-description">${course.description}</p>
                <div class="search-course-meta">
                    <span class="meta-item">
                        <i class="fas fa-signal"></i>
                        ${course.level}
                    </span>
                    <span class="meta-item">
                        <i class="fas fa-clock"></i>
                        ${course.duration}
                    </span>
                    <span class="meta-item">
                        <i class="fas fa-users"></i>
                        ${course.students.toLocaleString()} students
                    </span>
                    <span class="meta-item">
                        <i class="fas fa-tag"></i>
                        ${course.category}
                    </span>
                </div>
                <div class="search-course-tags">
                    ${course.tags.slice(0, 3).map(tag => 
                        `<span class="course-tag">${tag}</span>`
                    ).join('')}
                </div>
            </div>
            <div class="search-course-action">
                ${course.enrolled ? `
                    <button class="btn-primary" onclick="event.stopPropagation(); searchManager.continueCourse(${course.id})">
                        <i class="fas fa-play"></i>
                        Continue
                    </button>
                ` : `
                    <button class="btn-primary" onclick="event.stopPropagation(); searchManager.enrollCourse(${course.id})">
                        <i class="fas fa-plus"></i>
                        Enroll Now
                    </button>
                `}
                <button class="btn-outline" onclick="event.stopPropagation(); searchManager.viewCourse(${course.id})">
                    <i class="fas fa-info-circle"></i>
                    Details
                </button>
            </div>
        </div>
    `).join('');
}

    generateStars(rating) {
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 >= 0.5;
        let stars = '';
        
        for (let i = 0; i < fullStars; i++) {
            stars += '<i class="fas fa-star"></i>';
        }
        if (hasHalfStar) {
            stars += '<i class="fas fa-star-half-alt"></i>';
        }
        const emptyStars = 5 - Math.ceil(rating);
        for (let i = 0; i < emptyStars; i++) {
            stars += '<i class="far fa-star"></i>';
        }
        
        return stars;
    }

    clearAllFilters() {
        this.currentFilters = {
            category: 'all',
            rating: 'all',
            duration: 'all',
            level: 'all',
            sortBy: 'relevance'
        };

        // Reset UI
        document.querySelectorAll('.category-filter-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.category === 'all') {
                btn.classList.add('active');
            }
        });

        document.querySelectorAll('.filter-select').forEach(select => {
            select.value = 'all';
        });

        const sortSelect = document.getElementById('sortBy');
        if (sortSelect) sortSelect.value = 'relevance';

        this.applyFilters();
    }

    clearSearchAndFilters() {
        document.getElementById('globalSearch').value = '';
        this.clearAllFilters();
        this.hideSearchResults();
        this.displayDefaultCourses();
    }

    viewCourse(courseId) {
        const course = this.allCourses.find(c => c.id === courseId);
        if (!course) return;

        // Use the existing dashboard modal function
        if (typeof dashboard !== 'undefined' && dashboard.showCourseModal) {
            this.hideSearchResults();
            dashboard.showCourseModal(courseId);
        } else if (typeof teacherDashboard !== 'undefined' && teacherDashboard.showCourseManagement) {
            this.hideSearchResults();
            // For teacher dashboard, show management or viewing interface
            console.log('View course:', course);
        }
    }

    enrollCourse(courseId) {
        if (typeof dashboard !== 'undefined' && dashboard.enrollInCourse) {
            dashboard.enrollInCourse(courseId);
            // Reload courses to update enrolled status
            this.loadAllCourses();
            this.performSearch(document.getElementById('globalSearch').value);
        }
    }

    continueCourse(courseId) {
        if (typeof dashboard !== 'undefined' && dashboard.continueCourse) {
            dashboard.continueCourse(courseId);
        }
    }

    // Method to filter by instructor
    filterByInstructor(instructorName) {
        document.getElementById('globalSearch').value = instructorName;
        this.performSearch(instructorName);
        this.showSearchResults();
    }

    // Method to filter by category
    filterByCategory(category) {
        this.currentFilters.category = category;
        document.querySelectorAll('.category-filter-btn').forEach(btn => {
            btn.classList.remove('active');
            if (btn.dataset.category === category) {
                btn.classList.add('active');
            }
        });
        this.applyFilters();
        this.showSearchResults();
    }

    // Method to open discover mode from sidebar
    openDiscoverMode() {
        const searchInput = document.getElementById('globalSearch');
        if (searchInput) {
            searchInput.value = '';
        }
        this.showDiscoverMode();
    }
}

// Initialize search manager
let searchManager;
document.addEventListener('DOMContentLoaded', function() {
    // Small delay to ensure dashboard is loaded first
    setTimeout(() => {
        searchManager = new SearchManager();
    }, 100);
});