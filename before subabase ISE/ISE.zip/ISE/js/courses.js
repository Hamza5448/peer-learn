// Course Management System - UPDATED FOR IndexedDB
class CourseManager {
    constructor() {
        this.courses = [];
        this.enrollments = {};
        this.videoProgress = {};
        this.videoDB = null;
        this.initializeDB();
        this.loadFromStorage();
    }

    async initializeDB() {
        // Access the same IndexedDB used by course creation
        return new Promise((resolve, reject) => {
            const request = indexedDB.open('SkillShareVideoDB', 1);
            
            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.videoDB = request.result;
                console.log('✅ CourseManager: IndexedDB connected');
                resolve(this.videoDB);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                if (!db.objectStoreNames.contains('videos')) {
                    db.createObjectStore('videos', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('thumbnails')) {
                    db.createObjectStore('thumbnails', { keyPath: 'id' });
                }
            };
        });
    }

    async getVideoBlob(videoId) {
        if (!this.videoDB) {
            await this.initializeDB();
        }

        const transaction = this.videoDB.transaction(['videos'], 'readonly');
        const store = transaction.objectStore('videos');
        
        return new Promise((resolve, reject) => {
            const request = store.get(videoId);
            request.onsuccess = () => {
                if (request.result && request.result.blob) {
                    resolve(request.result.blob);
                } else {
                    resolve(null);
                }
            };
            request.onerror = () => reject(request.error);
        });
    }

    loadFromStorage() {
        try {
            this.courses = JSON.parse(localStorage.getItem('courses')) || [];
            this.enrollments = JSON.parse(localStorage.getItem('enrollments')) || {};
            this.videoProgress = JSON.parse(localStorage.getItem('videoProgress')) || {};
            console.log('Loaded courses:', this.courses);
            console.log('Loaded enrollments:', this.enrollments);
        } catch (error) {
            console.error('Error loading from storage:', error);
            this.courses = [];
            this.enrollments = {};
            this.videoProgress = {};
        }
    }

    saveToStorage() {
        try {
            localStorage.setItem('courses', JSON.stringify(this.courses));
            localStorage.setItem('enrollments', JSON.stringify(this.enrollments));
            localStorage.setItem('videoProgress', JSON.stringify(this.videoProgress));
            console.log('Saved courses:', this.courses);
        } catch (error) {
            console.error('Error saving to storage:', error);
        }
    }

    createCourse(courseData, creatorEmail) {
        console.log('Creating course with data:', courseData);
        console.log('Creator email:', creatorEmail);

        const course = {
            id: Date.now(),
            title: courseData.title || 'Untitled Course',
            description: courseData.description || '',
            category: courseData.category || 'General',
            thumbnail: courseData.thumbnail || '📚',
            creatorEmail: creatorEmail,
            creatorName: courseData.creatorName,
            videos: [],
            createdDate: new Date().toISOString(),
            updatedDate: new Date().toISOString(),
            published: true
        };

        this.courses.push(course);
        this.saveToStorage();
        
        console.log('Course created successfully:', course);
        return course;
    }

    getCourse(courseId) {
        const course = this.courses.find(c => c.id == courseId);
        console.log('Getting course', courseId, ':', course);
        return course;
    }

    updateCourse(courseId, updates) {
        console.log('🔧 UPDATE COURSE CALLED');
        console.log('   Course ID:', courseId);
        console.log('   Updates:', updates);
        
        if (updates.videos) {
            console.log('   📹 Videos count:', updates.videos.length);
        }
        
        const courseIndex = this.courses.findIndex(c => c.id == courseId);
        
        if (courseIndex !== -1) {
            console.log('   ✅ Found course at index:', courseIndex);
            
            const oldVideoCount = this.courses[courseIndex].videos?.length || 0;
            console.log('   📹 Old video count:', oldVideoCount);
            
            this.courses[courseIndex] = {
                ...this.courses[courseIndex],
                ...updates,
                updatedDate: new Date().toISOString()
            };
            
            const newVideoCount = this.courses[courseIndex].videos?.length || 0;
            console.log('   📹 New video count:', newVideoCount);
            
            if (updates.videos && newVideoCount !== updates.videos.length) {
                console.error('   ❌ VIDEO COUNT MISMATCH!');
            } else {
                console.log('   ✅ Videos updated correctly');
            }
            
            this.saveToStorage();
            console.log('   💾 Saved to localStorage');
            
            const verification = JSON.parse(localStorage.getItem('courses'));
            const verifiedCourse = verification.find(c => c.id == courseId);
            const verifiedVideoCount = verifiedCourse?.videos?.length || 0;
            
            console.log('   🔍 Verification from storage:', verifiedVideoCount, 'videos');
            
            return this.courses[courseIndex];
        }
        
        console.log('   ❌ Course not found with ID:', courseId);
        return null;
    }

    deleteCourse(courseId) {
        const courseIndex = this.courses.findIndex(c => c.id == courseId);
        if (courseIndex !== -1) {
            this.courses.splice(courseIndex, 1);
            
            Object.keys(this.enrollments).forEach(email => {
                this.enrollments[email] = this.enrollments[email].filter(id => id != courseId);
            });
            
            this.saveToStorage();
            console.log('Course deleted:', courseId);
            return true;
        }
        return false;
    }

    enrollUser(userEmail, courseId) {
        if (!this.enrollments[userEmail]) {
            this.enrollments[userEmail] = [];
        }
        
        const courseIdNum = parseInt(courseId);
        if (!this.enrollments[userEmail].includes(courseIdNum)) {
            this.enrollments[userEmail].push(courseIdNum);
            this.saveToStorage();
            console.log('User enrolled:', userEmail, 'in course:', courseIdNum);
            return true;
        }
        console.log('User already enrolled:', userEmail, 'in course:', courseIdNum);
        return false;
    }

    unenrollUser(userEmail, courseId) {
        if (this.enrollments[userEmail]) {
            const courseIdNum = parseInt(courseId);
            this.enrollments[userEmail] = this.enrollments[userEmail].filter(id => id != courseIdNum);
            this.saveToStorage();
            console.log('User unenrolled:', userEmail, 'from course:', courseIdNum);
            return true;
        }
        return false;
    }

    isEnrolled(userEmail, courseId) {
        const courseIdNum = parseInt(courseId);
        const enrolled = this.enrollments[userEmail]?.includes(courseIdNum) || false;
        return enrolled;
    }

    getUserCourses(userEmail) {
        const enrolledIds = this.enrollments[userEmail] || [];
        const courses = this.courses.filter(c => enrolledIds.includes(c.id));
        console.log('User courses for', userEmail, ':', courses.length);
        return courses;
    }

    getCreatedCourses(creatorEmail) {
        const courses = this.courses.filter(c => c.creatorEmail === creatorEmail);
        console.log('Created courses by', creatorEmail, ':', courses.length);
        return courses;
    }

    getAllCourses() {
        console.log('All courses:', this.courses.length);
        return this.courses;
    }

    searchCourses(query) {
        const lowerQuery = query.toLowerCase();
        const results = this.courses.filter(course => {
            const titleMatch = course.title.toLowerCase().includes(lowerQuery);
            const categoryMatch = course.category.toLowerCase().includes(lowerQuery);
            const creatorMatch = course.creatorName.toLowerCase().includes(lowerQuery);
            const descMatch = (course.description || '').toLowerCase().includes(lowerQuery);
            return titleMatch || categoryMatch || creatorMatch || descMatch;
        });
        console.log('Search results for "' + query + '":', results.length);
        return results;
    }

    saveVideoProgress(userEmail, courseId, videoId, currentTime, duration) {
        const key = `${userEmail}_${courseId}_${videoId}`;
        this.videoProgress[key] = {
            currentTime,
            duration,
            percentage: duration > 0 ? (currentTime / duration) * 100 : 0,
            lastUpdated: new Date().toISOString()
        };
        this.saveToStorage();
    }

    getVideoProgress(userEmail, courseId, videoId) {
        const key = `${userEmail}_${courseId}_${videoId}`;
        return this.videoProgress[key] || null;
    }

    getCourseProgress(userEmail, courseId) {
        const course = this.getCourse(courseId);
        if (!course || course.videos.length === 0) return 0;

        let totalProgress = 0;
        course.videos.forEach(video => {
            const progress = this.getVideoProgress(userEmail, courseId, video.id);
            if (progress) {
                totalProgress += progress.percentage;
            }
        });

        return totalProgress / course.videos.length;
    }
}

console.log('Initializing Course Manager...');
window.courseManager = new CourseManager();
console.log('Course Manager initialized with', window.courseManager.courses.length, 'courses');