// USING IndexedDB FOR LARGE VIDEO STORAGE (1GB+ support)
// IndexedDB can store much larger files than localStorage

class VideoStorageDB {
    constructor() {
        this.dbName = 'SkillShareVideoDB';
        this.dbVersion = 1;
        this.db = null;
    }

    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.dbName, this.dbVersion);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this.db = request.result;
                resolve(this.db);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                
                // Create object stores if they don't exist
                if (!db.objectStoreNames.contains('videos')) {
                    db.createObjectStore('videos', { keyPath: 'id' });
                }
                if (!db.objectStoreNames.contains('thumbnails')) {
                    db.createObjectStore('thumbnails', { keyPath: 'id' });
                }
            };
        });
    }

    async saveVideo(id, blob) {
        const transaction = this.db.transaction(['videos'], 'readwrite');
        const store = transaction.objectStore('videos');
        
        return new Promise((resolve, reject) => {
            const request = store.put({ id, blob, timestamp: Date.now() });
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    async getVideo(id) {
        const transaction = this.db.transaction(['videos'], 'readonly');
        const store = transaction.objectStore('videos');
        
        return new Promise((resolve, reject) => {
            const request = store.get(id);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }

    async deleteVideo(id) {
        const transaction = this.db.transaction(['videos'], 'readwrite');
        const store = transaction.objectStore('videos');
        
        return new Promise((resolve, reject) => {
            const request = store.delete(id);
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    async saveThumbnail(id, dataUrl) {
        const transaction = this.db.transaction(['thumbnails'], 'readwrite');
        const store = transaction.objectStore('thumbnails');
        
        return new Promise((resolve, reject) => {
            const request = store.put({ id, dataUrl, timestamp: Date.now() });
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    }

    async getThumbnail(id) {
        const transaction = this.db.transaction(['thumbnails'], 'readonly');
        const store = transaction.objectStore('thumbnails');
        
        return new Promise((resolve, reject) => {
            const request = store.get(id);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
}

class CourseCreationManager {
    constructor() {
        this.currentUser = null;
        this.courseData = {
            title: '',
            description: '',
            category: 'Web Development',
            thumbnail: null,
            videos: []
        };
        this.currentVideoIndex = null;
        this.isEditMode = false;
        this.editCourseId = null;
        this.videoBlobs = {}; // Store video blob URLs for preview
        this.videoDB = new VideoStorageDB();
        this.initialize();
    }

    async initialize() {
        try {
            await this.videoDB.init();
            console.log('✅ IndexedDB initialized - can now store 1GB+ videos!');
        } catch (error) {
            console.error('❌ IndexedDB initialization failed:', error);
            showNotification('Storage initialization failed. Please refresh the page.', 'error');
        }
        
        this.checkAuthentication();
        this.setupEventListeners();
        this.loadExistingCourse();
    }

    checkAuthentication() {
        const currentUserEmail = localStorage.getItem('currentUser');
        if (!currentUserEmail) {
            window.location.href = 'index.html';
            return;
        }
        
        const userProfiles = JSON.parse(localStorage.getItem('userProfiles') || '{}');
        this.currentUser = userProfiles[currentUserEmail];
        
        if (!this.currentUser || this.currentUser.userType !== 'teacher') {
            window.location.href = 'dashboard.html';
            return;
        }
    }

    async loadExistingCourse() {
        const urlParams = new URLSearchParams(window.location.search);
        const courseId = urlParams.get('courseId');
        
        if (courseId) {
            this.isEditMode = true;
            this.editCourseId = parseInt(courseId);
            const course = window.courseManager.getCourse(courseId);
            
            if (course && course.creatorEmail === this.currentUser.email) {
                this.courseData = {
                    title: course.title,
                    description: course.description,
                    category: course.category,
                    thumbnail: course.thumbnail,
                    videos: []
                };
                
                // Load videos from IndexedDB
                for (let video of course.videos) {
                    const storedVideo = await this.videoDB.getVideo(video.id);
                    if (storedVideo) {
                        // Create blob URL for preview
                        const blobUrl = URL.createObjectURL(storedVideo.blob);
                        this.videoBlobs[video.id] = blobUrl;
                        
                        this.courseData.videos.push({
                            ...video,
                            blobUrl: blobUrl
                        });
                    } else {
                        // Video metadata exists but blob is missing
                        this.courseData.videos.push(video);
                    }
                }
                
                console.log('✅ Loaded course for editing:', this.courseData.title);
                console.log('📹 Videos loaded:', this.courseData.videos.length);
                
                this.renderCourseInfo();
                this.renderPlaylist();
                if (this.courseData.videos.length > 0) {
                    this.selectVideo(0);
                }
            }
        }
    }

    setupEventListeners() {
        // Course thumbnail upload
        const thumbnailInput = document.getElementById('courseThumbnailInput');
        const thumbnailBox = document.getElementById('courseThumbnailBox');
        
        if (thumbnailBox) {
            thumbnailBox.addEventListener('click', () => thumbnailInput.click());
        }
        
        if (thumbnailInput) {
            thumbnailInput.addEventListener('change', (e) => this.handleCourseThumbnailUpload(e));
        }

        // Course info inputs
        const titleInput = document.getElementById('courseTitle');
        const descInput = document.getElementById('courseDescription');
        const categoryInput = document.getElementById('courseCategory');
        
        if (titleInput) titleInput.addEventListener('input', (e) => {
            this.courseData.title = e.target.value;
        });
        
        if (descInput) descInput.addEventListener('input', (e) => {
            this.courseData.description = e.target.value;
        });
        
        if (categoryInput) categoryInput.addEventListener('change', (e) => {
            this.courseData.category = e.target.value;
        });

        // Video upload zone
        const uploadZone = document.getElementById('uploadZone');
        const videoInput = document.getElementById('videoInput');
        
        if (uploadZone) {
            uploadZone.addEventListener('click', () => videoInput.click());
            
            uploadZone.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadZone.classList.add('drag-over');
            });
            
            uploadZone.addEventListener('dragleave', () => {
                uploadZone.classList.remove('drag-over');
            });
            
            uploadZone.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadZone.classList.remove('drag-over');
                const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('video/'));
                this.handleVideoUpload(files);
            });
        }
        
        if (videoInput) {
            videoInput.addEventListener('change', (e) => {
                const files = Array.from(e.target.files);
                this.handleVideoUpload(files);
            });
        }

        // Fullscreen toggle
        const fullscreenBtn = document.getElementById('fullscreenToggle');
        if (fullscreenBtn) {
            fullscreenBtn.addEventListener('click', () => this.toggleFullscreen());
        }

        // Save course button
        const saveBtn = document.getElementById('saveCourseBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => this.saveCourse());
        }

        // Cancel button
        const cancelBtn = document.getElementById('cancelBtn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => {
                if (confirm('Discard changes and return to dashboard?')) {
                    // Clean up blob URLs
                    Object.values(this.videoBlobs).forEach(url => URL.revokeObjectURL(url));
                    window.location.href = 'teacher-dashboard.html';
                }
            });
        }

        // ESC key for fullscreen
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const container = document.getElementById('videoPreviewContainer');
                if (container && container.classList.contains('fullscreen')) {
                    this.toggleFullscreen();
                }
            }
        });
    }

    handleCourseThumbnailUpload(e) {
        const file = e.target.files[0];
        if (!file || !file.type.startsWith('image/')) {
            showNotification('Please select a valid image file', 'error');
            return;
        }

        const reader = new FileReader();
        reader.onload = (event) => {
            this.courseData.thumbnail = event.target.result;
            this.renderCourseThumbnail();
        };
        reader.readAsDataURL(file);
    }

    renderCourseThumbnail() {
        const box = document.getElementById('courseThumbnailBox');
        if (this.courseData.thumbnail) {
            box.innerHTML = `
                <img src="${this.courseData.thumbnail}" alt="Course thumbnail">
                <button class="thumbnail-remove-btn" onclick="event.stopPropagation(); courseCreation.removeCourseThumbnail()">
                    <i class="fas fa-times"></i>
                </button>
            `;
            box.classList.add('has-image');
        } else {
            box.innerHTML = `
                <div class="thumbnail-placeholder">
                    <i class="fas fa-image"></i>
                    <p>Click to upload thumbnail</p>
                    <small>(Optional, 16:9 recommended)</small>
                </div>
            `;
            box.classList.remove('has-image');
        }
    }

    removeCourseThumbnail() {
        this.courseData.thumbnail = null;
        this.renderCourseThumbnail();
        showNotification('Course thumbnail removed', 'info');
    }

    renderCourseInfo() {
        document.getElementById('courseTitle').value = this.courseData.title;
        document.getElementById('courseDescription').value = this.courseData.description;
        document.getElementById('courseCategory').value = this.courseData.category;
        this.renderCourseThumbnail();
    }

    async handleVideoUpload(files) {
        const MAX_SIZE = 1 * 1024 * 1024 * 1024; // 1GB limit
        
        for (const file of files) {
            if (file.size > MAX_SIZE) {
                showNotification(`Video "${file.name}" exceeds 1GB limit`, 'error');
                continue;
            }

            showNotification(`Uploading ${file.name} (${this.formatBytes(file.size)})...`, 'info');

            try {
                const videoId = 'video_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
                
                // Store video blob in IndexedDB
                await this.videoDB.saveVideo(videoId, file);
                
                // Create blob URL for preview
                const blobUrl = URL.createObjectURL(file);
                this.videoBlobs[videoId] = blobUrl;
                
                // Store video metadata
                const newVideo = {
                    id: videoId,
                    name: file.name.replace(/\.[^/.]+$/, ''),
                    thumbnail: null,
                    size: file.size,
                    type: file.type,
                    duration: 0,
                    addedDate: new Date().toISOString(),
                    blobUrl: blobUrl // For preview only
                };
                
                this.courseData.videos.push(newVideo);
                
                console.log('✅ Video added to IndexedDB:', newVideo.name);
                console.log('📹 Total videos:', this.courseData.videos.length);
                console.log('💾 Video size:', this.formatBytes(file.size));

                this.renderPlaylist();
                showNotification(`${file.name} uploaded successfully!`, 'success');
                
                if (this.courseData.videos.length === 1) {
                    this.selectVideo(0);
                }
            } catch (error) {
                console.error('Upload error:', error);
                showNotification(`Failed to upload ${file.name}: ${error.message}`, 'error');
            }
        }
    }

    renderPlaylist() {
        const container = document.getElementById('playlistVideos');
        const countEl = document.getElementById('playlistCount');
        
        if (countEl) {
            countEl.textContent = this.courseData.videos.length;
        }

        if (this.courseData.videos.length === 0) {
            container.innerHTML = `
                <div class="playlist-empty">
                    <i class="fas fa-video-slash"></i>
                    <p>No videos yet</p>
                    <small>Upload videos up to 1GB each</small>
                </div>
            `;
            return;
        }

        container.innerHTML = this.courseData.videos.map((video, index) => `
            <div class="playlist-video-item ${this.currentVideoIndex === index ? 'active' : ''}" 
                 draggable="true"
                 data-index="${index}"
                 onclick="courseCreation.selectVideo(${index})">
                <div class="video-item-header">
                    <i class="fas fa-grip-vertical drag-handle"></i>
                    <div class="video-number">${index + 1}</div>
                    <div class="video-item-info">
                        <strong style="color: var(--text-primary); font-size: 0.85rem; display: block; margin-bottom: 0.25rem;">${video.name}</strong>
                        <small style="color: var(--text-secondary); font-size: 0.75rem;">${this.formatBytes(video.size)}</small>
                    </div>
                    <div class="video-item-actions">
                        <button class="video-item-btn danger" onclick="event.stopPropagation(); courseCreation.deleteVideo(${index})" title="Delete">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                
                <div class="video-thumbnail-small" onclick="event.stopPropagation();">
                    ${video.thumbnail ? 
                        `<img src="${video.thumbnail}" alt="Video thumbnail">` : 
                        `<div class="thumbnail-placeholder">
                            <i class="fas fa-image"></i>
                        </div>`
                    }
                    <div class="thumbnail-overlay">
                        <i class="fas fa-camera" onclick="courseCreation.uploadVideoThumbnail(${index})" title="Upload thumbnail"></i>
                        ${video.thumbnail ? `
                            <button class="remove-thumb-btn" onclick="courseCreation.removeVideoThumbnail(${index})" title="Remove thumbnail">
                                <i class="fas fa-trash"></i>
                            </button>
                        ` : ''}
                    </div>
                </div>
                
                <input type="text" 
                       class="video-name-input" 
                       value="${video.name}"
                       onclick="event.stopPropagation()"
                       onchange="courseCreation.updateVideoName(${index}, this.value)"
                       placeholder="Video title">
            </div>
        `).join('');

        this.setupDragAndDrop();
    }

    setupDragAndDrop() {
        const items = document.querySelectorAll('.playlist-video-item');
        let draggedItem = null;
        let draggedIndex = null;

        items.forEach((item, index) => {
            item.addEventListener('dragstart', (e) => {
                draggedItem = item;
                draggedIndex = index;
                item.classList.add('dragging');
                e.dataTransfer.effectAllowed = 'move';
            });

            item.addEventListener('dragend', () => {
                item.classList.remove('dragging');
            });

            item.addEventListener('dragover', (e) => {
                e.preventDefault();
            });

            item.addEventListener('drop', (e) => {
                e.preventDefault();
                const dropIndex = parseInt(item.dataset.index);
                
                if (draggedIndex !== dropIndex) {
                    const [movedVideo] = this.courseData.videos.splice(draggedIndex, 1);
                    this.courseData.videos.splice(dropIndex, 0, movedVideo);
                    
                    if (this.currentVideoIndex === draggedIndex) {
                        this.currentVideoIndex = dropIndex;
                    } else if (this.currentVideoIndex > draggedIndex && this.currentVideoIndex <= dropIndex) {
                        this.currentVideoIndex--;
                    } else if (this.currentVideoIndex < draggedIndex && this.currentVideoIndex >= dropIndex) {
                        this.currentVideoIndex++;
                    }
                    
                    this.renderPlaylist();
                }
            });
        });
    }

    selectVideo(index) {
        this.currentVideoIndex = index;
        const video = this.courseData.videos[index];
        
        const videoPlayer = document.getElementById('videoPreview');
        const videoSource = document.getElementById('videoPreviewSource');
        const videoInfo = document.getElementById('videoInfoDisplay');
        const placeholder = document.getElementById('videoPlaceholder');
        
        if (video && video.blobUrl) {
            videoSource.src = video.blobUrl;
            videoPlayer.load();
            videoPlayer.style.display = 'block';
            placeholder.style.display = 'none';
            
            videoInfo.innerHTML = `
                <h4>${video.name}</h4>
                <p>
                    <i class="fas fa-video"></i>
                    Video ${index + 1} of ${this.courseData.videos.length}
                    • ${this.formatBytes(video.size)}
                </p>
            `;
        }
        
        this.renderPlaylist();
    }

    uploadVideoThumbnail(index) {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        
        input.onchange = (e) => {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = async (event) => {
                const thumbnailData = event.target.result;
                this.courseData.videos[index].thumbnail = thumbnailData;
                
                // Save thumbnail to IndexedDB
                await this.videoDB.saveThumbnail(this.courseData.videos[index].id, thumbnailData);
                
                this.renderPlaylist();
                showNotification('Thumbnail updated!', 'success');
            };
            reader.readAsDataURL(file);
        };
        
        input.click();
    }

    removeVideoThumbnail(index) {
        this.courseData.videos[index].thumbnail = null;
        this.renderPlaylist();
        showNotification('Video thumbnail removed', 'info');
    }

    updateVideoName(index, newName) {
        if (newName.trim()) {
            this.courseData.videos[index].name = newName.trim();
            if (this.currentVideoIndex === index) {
                this.selectVideo(index);
            }
        }
    }

    async deleteVideo(index) {
        if (confirm('Delete this video?')) {
            const video = this.courseData.videos[index];
            
            // Delete from IndexedDB
            await this.videoDB.deleteVideo(video.id);
            
            // Revoke blob URL
            if (this.videoBlobs[video.id]) {
                URL.revokeObjectURL(this.videoBlobs[video.id]);
                delete this.videoBlobs[video.id];
            }
            
            this.courseData.videos.splice(index, 1);
            
            if (this.currentVideoIndex === index) {
                if (this.courseData.videos.length > 0) {
                    this.selectVideo(Math.min(index, this.courseData.videos.length - 1));
                } else {
                    this.currentVideoIndex = null;
                    document.getElementById('videoPreview').style.display = 'none';
                    document.getElementById('videoPlaceholder').style.display = 'flex';
                }
            } else if (this.currentVideoIndex > index) {
                this.currentVideoIndex--;
            }
            
            this.renderPlaylist();
            showNotification('Video deleted', 'success');
        }
    }

    toggleFullscreen() {
        const container = document.getElementById('videoPreviewContainer');
        const btn = document.getElementById('fullscreenToggle');
        
        if (!container.classList.contains('fullscreen')) {
            container.classList.add('fullscreen');
            btn.innerHTML = '<i class="fas fa-compress"></i><span>Exit Fullscreen</span>';
            
            if (container.requestFullscreen) {
                container.requestFullscreen();
            } else if (container.webkitRequestFullscreen) {
                container.webkitRequestFullscreen();
            }
        } else {
            container.classList.remove('fullscreen');
            btn.innerHTML = '<i class="fas fa-expand"></i><span>Fullscreen</span>';
            
            if (document.exitFullscreen) {
                document.exitFullscreen();
            } else if (document.webkitExitFullscreen) {
                document.webkitExitFullscreen();
            }
        }
    }

    async saveCourse() {
        console.log('🔵 ========== SAVE COURSE STARTED ==========');
        
        if (!this.courseData.title.trim()) {
            showNotification('Please enter a course title', 'error');
            return;
        }

        if (this.courseData.videos.length === 0) {
            showNotification('Please add at least one video', 'error');
            return;
        }

        const saveBtn = document.getElementById('saveCourseBtn');
        if (saveBtn) {
            saveBtn.disabled = true;
            saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';
        }

        try {
            // Save video metadata (NOT the blob data)
            const videosMetadata = this.courseData.videos.map(v => ({
                id: v.id,
                name: v.name,
                thumbnail: v.thumbnail,
                size: v.size,
                type: v.type,
                duration: v.duration,
                addedDate: v.addedDate
                // blobUrl is NOT saved - it's temporary
            }));

            let savedCourseId;
            
            if (this.isEditMode) {
                console.log('🔵 Updating course:', this.editCourseId);
                
                const updated = window.courseManager.updateCourse(this.editCourseId, {
                    title: this.courseData.title,
                    description: this.courseData.description,
                    category: this.courseData.category,
                    thumbnail: this.courseData.thumbnail || '📚',
                    videos: videosMetadata
                });
                
                console.log('✅ Course updated');
                console.log('✅ Videos count:', updated.videos.length);
                
                savedCourseId = this.editCourseId;
                showNotification('Course updated successfully!', 'success');
            } else {
                console.log('🔵 Creating new course');
                
                const courseInfo = {
                    title: this.courseData.title,
                    description: this.courseData.description,
                    category: this.courseData.category,
                    thumbnail: this.courseData.thumbnail || '📚',
                    creatorName: `${this.currentUser.firstName} ${this.currentUser.lastName}`
                };
                
                const course = window.courseManager.createCourse(courseInfo, this.currentUser.email);
                savedCourseId = course.id;

                const updatedCourse = window.courseManager.updateCourse(course.id, { 
                    videos: videosMetadata
                });
                
                console.log('✅ Course created');
                console.log('✅ Videos count:', updatedCourse.videos.length);
                
                showNotification('Course created successfully!', 'success');
            }

            if (typeof searchManager !== 'undefined') {
                searchManager.loadAllCourses();
            }

            const verifiedCourse = window.courseManager.getCourse(savedCourseId);
            console.log('🔍 VERIFICATION:', verifiedCourse.videos.length, 'videos saved');
            console.log('🔵 ========== SAVE COURSE SUCCESS ==========');

            setTimeout(() => {
                window.location.href = 'teacher-dashboard.html';
            }, 1500);
            
        } catch (error) {
            console.error('❌ Error saving course:', error);
            showNotification(error.message || 'Failed to save course', 'error');
            
            if (saveBtn) {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '<i class="fas fa-save"></i> Save Course';
            }
        }
    }

    formatBytes(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
}

let courseCreation;
document.addEventListener('DOMContentLoaded', () => {
    courseCreation = new CourseCreationManager();
});

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;

    if (!document.querySelector('.notification-styles')) {
        const styles = document.createElement('style');
        styles.className = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 1rem 1.5rem;
                border-radius: 8px;
                color: white;
                font-weight: 500;
                z-index: 10001;
                display: flex;
                align-items: center;
                gap: 1rem;
                max-width: 400px;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.3);
            }
            .notification-success { background: rgba(16, 185, 129, 0.9); }
            .notification-error { background: rgba(239, 68, 68, 0.9); }
            .notification-info { background: rgba(59, 130, 246, 0.9); }
            .notification button {
                background: none;
                border: none;
                color: white;
                font-size: 1.2rem;
                cursor: pointer;
            }
        `;
        document.head.appendChild(styles);
    }

    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}